/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet.statistics;

import anavanet.statistics.PacketStatistic.MRLink;
import java.util.GregorianCalendar;

/**
 * Wrapper for statistics of packets sent in a period of time.
 *
 * @author Jos� Santa Lozano
 * @author Manabu Tsukada
 */
public class StatisticInfo {

    // UTC-GPS time for the analysis
    private long utcTime;
    // Local time of source MR for the analysis
    private long localTime;
    // MR identifiers
    private String[] mrIds;
    // Latitude of the MR's positions
    private double[] latitudes;
    // Longitude of the MR's positions'
    private double[] longitudes;
    // Speed of vehicles
    private double[] speeds;
    // Distances between mobile routers
    private double[] distances;
    // Message delivery ratio
    private double pdr;
    // Mean RTT delay
    private double rtt;
    // Behaviour of links
    private PacketStatistic.MRLink[] mrLinks;
    // Bytes transmitted
    private long bytes;
    // Channel bandwidth
    private double bandwidth;
    // Jitter of the communication
    private double jitter;
    // RTT of the channel from end-to-end
    private double e2eRtt;
    // Number of logged packets in the period
    private int loggedPackets;
    // Status of Binding
    // 0: not sent, 1: BU/BA success, 2: BU fails
    private int NEMO_status;

    /**
     * Creates a new wrapper for packet statistics in a period of time.
     *
     * @param utcTime GPS-UTC Time for the analysis.
     * @param localTime Local time at the source MR for the analysis.
     * @param mrIds Identifiers of MRs.
     * @param latitudes Latitude for each MR position.
     * @param longitudes Longitude for each MR position.
     * @param speeds Speed of vehicles.
     * @param distances Distance between each pair of MR.
     * @param pdr Message delivery ratio.
     * @param rtt Mean round trip time, taking as reference the source MR.
     * @param mrLinks Behaviour of links.
     * @param loggedPackets Number of logged packets.
     */
    public StatisticInfo(long utcTime, long localTime, String[] mrIds, double[] latitudes, double[] longitudes, double[] speeds, double[] distances, double pdr, double rtt, PacketStatistic.MRLink[] mrLinks, int bytes, double bandwidth, double jitter, int loggedPackets, int NEMO_status) {

        this.utcTime = utcTime;
        this.localTime = localTime;
        this.mrIds = mrIds;
        this.latitudes = latitudes;
        this.longitudes = longitudes;
        this.speeds = speeds;
        this.distances = distances;
        this.pdr = pdr;
        this.rtt = rtt;
        this.mrLinks = mrLinks;
        this.bytes = bytes;
        this.bandwidth = bandwidth;
        this.jitter = jitter;
        this.loggedPackets = loggedPackets;
        this.e2eRtt = -1;
        this.NEMO_status = NEMO_status;
    }

    /**
     * Creates a new wrapper for packet statistics in a period of time.
     *
     * @param utcTime GPS-UTC Time for the analysis.
     * @param localTime Local time at the source MR for the analysis.
     * @param mrIds Identifiers of MRs.
     * @param latitudes Latitude for each MR position.
     * @param longitudes Longitude for each MR position.
     * @param speeds Speed of vehicles.
     * @param distances Distance between each pair of MR.
     */
    public StatisticInfo(long utcTime, long localTime, String[] mrIds, double[] latitudes, double[] longitudes, double[] speeds, double[] distances, int NEMO_status) {

        this.utcTime = utcTime;
        this.localTime = localTime;
        this.mrIds = mrIds;
        this.latitudes = latitudes;
        this.longitudes = longitudes;
        this.speeds = speeds;
        this.distances = distances;
        this.pdr = -1;
        this.rtt = -1;
        this.mrLinks = null;
        this.bytes = -1;
        this.bandwidth = -1;
        this.jitter = -1;
        this.e2eRtt = -1;
        this.NEMO_status = NEMO_status;

    }

    /**
     * Get the mobile routers identifiers of the desired path for the packets.
     *
     * @return MR identifers.
     */
    public String[] getMrIds() {

        return mrIds;
    }

    /**
     * Get the latitude of each MR position.
     *
     * @return The latitude in degrees.
     */
    public double[] getLatitudes() {
        return latitudes;
    }

    /**
     * Get the longitude of each MR position.
     *
     * @return THe longitude in degrees.
     */
    public double[] getLongitudes() {
        return longitudes;
    }

    /**
     * Get the speed of vehicles.
     *
     * @return The speed of vehicles in Km/h.
     */
    public double[] getSpeeds() {
        return speeds;
    }

    /**
     * Get the distances between each pair of mobile routers.
     *
     * @return The distances in meters.
     */
    public double[] getDistances() {
        return distances;
    }

    /**
     * Get the packet delivery ratio.
     *
     * @return The PDR in a value between 0 and 1.
     */
    public double getPDR() {
        return pdr;
    }

    /**
     * Get the round trip time taking as reference the first MR.
     *
     * @return The RTT in milliseconds.
     */
    public double getRtt() {
        return rtt;
    }

    /**
     * Get the bytes transmitted.
     *
     * @return The number of bytes.
     */
    public long getBytes() {

        return bytes;
    }

    /**
     * Set the bytes transmitted.
     *
     * @param bytes Number of bytes.
     */
    public void setBytes(long bytes) {

        this.bytes = bytes;
    }

    /**
     * Get the mean bandwith of the channle for the period.
     *
     * @return The bandwidth in bits/seconds.
     */
    public double getBandwith() {

        return bandwidth;
    }

    /**
     * Set the mean bandwith of the channel for the period.
     *
     * @param bandwidth The bandwidth in bits/seconds
     */
    public void setBandwidth(long bandwidth) {

        this.bandwidth = bandwidth;
    }

    /**
     * Get the jitter of the channel for the period.
     *
     * @return The jitter in milliseconds.
     */
    public double getJitter() {

        return jitter;
    }

    /**
     * Set the mean jitter of the channel for the period.
     *
     * @param jitter The jitter in ms.
     */
    public void setJitter(double jitter) {

        this.jitter = jitter;
    }

    /**
     * Set the end-to-end RTT of the channel.
     *
     * @param rtt The RTT in ms.
     */
    public void setE2eRtt(double rtt) {

        this.e2eRtt = rtt;
    }

    /**
     * Get the number of logged packets in the period.
     *
     * @return The number of packets.
     */
    public int getLoggedPackets() {

        return loggedPackets;
    }

    /**
     * Merge the links saved in the satistic information with a global set of links.
     *
     * @param globalLinks The set of links to merge.
     */
    public void mergeLinks(MRLink[] globalLinks) {

        // Create a new list of links from the global one
        MRLink[] result = new MRLink[globalLinks.length];
        for (int i = 0; i < globalLinks.length; i++) {
            result[i] = (MRLink) globalLinks[i].clone();
            result[i].clear();
        }

        // Copy information from local links
        for (int i = 0; i < globalLinks.length; i++) {
            for (int j = 0; j < mrLinks.length; j++) {

                if (globalLinks[i].equals(mrLinks[j])) {
                    result[i] = mrLinks[j];
                }
            }
        }

        mrLinks = result;
    }

    public String toString() {

        String result = "<marker ";

        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTimeInMillis(utcTime);
        result += "date=\"" + calendar.get(calendar.DAY_OF_MONTH) + "/" + (calendar.get(calendar.MONTH) + 1) + "/" + calendar.get(calendar.YEAR) + "\"";
        result += " time=\"" + calendar.get(calendar.HOUR_OF_DAY) + ":" + calendar.get(calendar.MINUTE) + ":" + calendar.get(calendar.SECOND) + "\"";
        calendar.setTimeInMillis(localTime);
        result += " dateL=\"" + calendar.get(calendar.DAY_OF_MONTH) + "/" + (calendar.get(calendar.MONTH) + 1) + "/" + calendar.get(calendar.YEAR) + "\"";
        result += " timeL=\"" + calendar.get(calendar.HOUR_OF_DAY) + ":" + calendar.get(calendar.MINUTE) + ":" + calendar.get(calendar.SECOND) + "\"";

        for (int i = 0; i < mrIds.length; i++) {
            result += " lat_" + mrIds[i] + "=\"" + latitudes[i] + "\" lng_" + mrIds[i] + "=\"" + longitudes[i] + "\" speed_" + mrIds[i] + "=\"" + speeds[i] + "\"";
        }

        for (int i = 1; i < distances.length; i++) {
            result += " distance_" + mrIds[i - 1] + "_" + mrIds[i] + "=\"" + distances[i] + "\"";
        }

        for (int i = 0; mrLinks != null && i < mrLinks.length; i++) {
            if (mrLinks[i].getPdr() >= 0) {
                result += " PDRlink_" + mrLinks[i].getMr1() + "_" + mrLinks[i].getMr2() + "=\"" + mrLinks[i].getPdr() + "\"";
            } else {
                result += " PDRlink_" + mrLinks[i].getMr1() + "_" + mrLinks[i].getMr2() + "=\"0\"";
            }
        }

        if (pdr >= 0) {
            result += " PDR=\"" + pdr + "\"";
        } else {
            result += " PDR=\"0\"";
        }

        if (bytes >= 0) {
            result += " bytes=\"" + bytes + "\"";
        } else {
            result += " bytes=\"0\"";
        }

        if (bandwidth >= 0) {
            result += " bandwidth=\"" + bandwidth + "\"";
        } else {
            result += " bandwidth=\"0\"";
        }

        if (jitter >= 0) {
            result += " jitter=\"" + jitter + "\"";
        } else {
            result += " jitter=\"0\"";
        }

        if (e2eRtt >= 0) {
            result += " rtt=\"" + e2eRtt + "\"";
        } else {
            result += " rtt=\"0\"";
        }

        result += " NEMO_status=\"" + NEMO_status + "\"";


        result += " />";

        return result;
    }

    public long getUtcTime() {
        return utcTime;
    }

    public long getLocalTime() {
        return localTime;
    }
}
