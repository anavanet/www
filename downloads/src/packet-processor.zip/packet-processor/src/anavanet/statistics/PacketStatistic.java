/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */


package anavanet.statistics;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Vector;

/**
 * Class with functionalities for calculating statitics from packets.
 *
 * @author Jos� Santa Lozano
 * @author Manabu Tsukada
 */
public class PacketStatistic {

    // Packet identifiers
    private Vector<Long> packetIds;
    // Name of mobile routers
    private Vector<String[]> mobileRouters;
    // Local times in the reception of packets
    private Vector<long[]> localTimes;
    // Next hop for the packet in each MR
    private Vector<String[]> nextHops;
    // Lenght of the logged packets
    private Vector<Integer> lenghts;
    // Latitude of the MR's positions
    private double[] latitudes;
    // Longitude of the MR's positions'
    private double[] longitudes;
    // Speed of vehicles
    private double[] speeds;
    // Distances between mobile routers
    private double[] distances;

    /**
     * Creates a new statistic object without any packet information.
     *
     * @param latitudes Latitude of each MR position.
     * @param longitudes Longitude of each MR position.
     * @param speeds Speed of vehicles.
     * @param distances Distances between each pair of MR.
     */
    public PacketStatistic(double[] latitudes, double[] longitudes, double[] speeds, double[] distances) {

        packetIds = new Vector<Long>();
        mobileRouters = new Vector<String[]>();
        localTimes = new Vector<long[]>();
        nextHops = new Vector<String[]>();
        lenghts = new Vector<Integer>();

        this.latitudes = latitudes;
        this.longitudes = longitudes;
        this.speeds = speeds;
        this.distances = distances;
    }

    /**
     * Add information about one packet emmited at source MR.
     *
     * @param packetId Packet identifier.
     * @param mobileRouters Mobile routers which have logged the packet.
     * @param localTimes Local time of each MRs which have logged the packet.
     * @param nextHops Next hop for the packet in each MR.
     * @param length Packet length, in bytes.
     */
    public void addPacketInfo(long packetId, String[] mobileRouters, long[] localTimes, String[] nextHops, int length) {

        packetIds.add(new Long(packetId));
        this.mobileRouters.add(mobileRouters);
        this.localTimes.add(localTimes);
        this.nextHops.add(nextHops);
        lenghts.add(length);
    }

    /**
     * Gets the message delivery ratio for the stored packets, considering the first MR as
     * the source.
     *
     * @return The DPR in a value between 0 and 1.
     */
    public double calculatePDR() {

        // Analise if each packet has arrived to the destination
        long deliveredPackets = 0;


        for (int i = 0; i < packetIds.size(); i++) {

            String[] mrs = mobileRouters.get(i);
            String[] nextMrs = nextHops.get(i);
            String lastMR = mrs[mrs.length - 1];
            if (lastMR.endsWith("x")) {
                lastMR = lastMR.substring(0, mrs[mrs.length - 1].indexOf("x"));
            }
            if (lastMR.equals(nextMrs[mrs.length - 1])) {
                deliveredPackets++;
            }
        }
        double pdr = 0;
        if (packetIds.size() > 0) {
            pdr = (double) deliveredPackets / packetIds.size();
        } else {
            pdr = -1;
        }

        return pdr;
    }

    /**
     * Gets the delay mean for the stored packets, considering the first MR as the source for
     * computing RTT.
     *
     * @return The RTT for each packet, packets which have been lost or haven't come back to the source MR
     * are not considered in the calculation.
     */
    public double calculateRTT() {

        // Check for each packet sent if it has come back, and compute the RTT
        long deliveredPackets = 0;
        double cumulativeRTT = 0;

        for (int i = 0; i < packetIds.size(); i++) {

            String[] mrs = mobileRouters.get(i);
            long[] timeStamps = localTimes.get(i);
            if (mrs[mrs.length - 1].equals(mrs[0]) || mrs[mrs.length - 1].equals(mrs[0]+"x")) {

//            for (int n = 0; n < destMRNumFromLast; n++) {
//                if (mrs[mrs.length - 1 - n].equals(mrs[0])) {
                deliveredPackets++;
                cumulativeRTT += timeStamps[timeStamps.length - 1] - timeStamps[0];
//                }
            }
        }

        double meanRTT = 0;
        if (deliveredPackets > 0) {
            meanRTT = cumulativeRTT / deliveredPackets;
        } else {
            meanRTT = -1;
        }
        return meanRTT;
    }

    /**
     * Gets the links followed by packets.
     *
     * @return An array of links followed by packets, and the PDR associated with each one.
     */
    public MRLink[] calculatePDRByLink(MRLink[] cachedMRLinks) {

        // Use the previous links created (only the names)
        Vector<MRLink> mrLinks = new Vector<MRLink>();
        if (cachedMRLinks != null && cachedMRLinks.length > 0) {
            for (int i = 0; i < cachedMRLinks.length; i++) {
                MRLink clonedMRLink = (MRLink) cachedMRLinks[i].clone();
                clonedMRLink.clear();
                mrLinks.add(clonedMRLink);
            }
        }

        for (int i = 0; i < packetIds.size(); i++) {

            // Follow the route of the packet
            MRLink previousMrLink = null;
            String currentMr = mobileRouters.get(i)[0];
            String nextMr = null;
            int index = 0;
            while (true) {

                // Check for the end of the path
                if (index >= nextHops.get(i).length) {
                    break;
                }

                // Get the next node
                nextMr = nextHops.get(i)[index];

                index++;

                // Update the number of packets received in the previous link
                if (previousMrLink != null) {
                    previousMrLink.newPacketOK();
                }

                // Check for the end of the path
                MRLink mrLink = null;
//                if (!nextMr.equals(currentMr) && !currentMr.equals(nextMr + "x")) {

                mrLink = searchLink(currentMr, nextMr, mrLinks);

                // If the link does not exist, create a new one
                if (mrLink == null) {
                    mrLink = new MRLink(currentMr, nextMr);
                    mrLinks.add(mrLink);
                }

                // Update the number of packets in the link
                mrLink.newPacketInLink();
//                } else {
//                    break;
//                }

                previousMrLink = mrLink;
                currentMr = nextMr;
            }
        }

        return mrLinks.toArray(new MRLink[0]);
    }

    /**
     * Returns the sum of bytes of the packets received.
     *
     * @return The number of bytes.
     */
    public int calculateReceivedBytes() {

        // Analise if each packet has arrived to the destination and add the length
        int bytes = 0;
        for (int i = 0; i < packetIds.size(); i++) {

            String[] mrs = mobileRouters.get(i);
            String[] nextMrs = nextHops.get(i);
            String lastMR = mrs[mrs.length - 1];
            int length = lenghts.get(i);
            if (lastMR.endsWith("x")) {
                lastMR = lastMR.substring(0, mrs[mrs.length - 1].indexOf("x"));
            }
            if (lastMR.equals(nextMrs[mrs.length - 1])) {
                bytes += length;
            }
        }

        return bytes;
    }

    /**
     * Calculates the effective bandwidth in the period of time.
     *
     * @param The interval of time of the study, in seconds.
     * @return The bandwidth, in b/s.
     */
    public double calculateBandwidth(double interval) {

        // Analise if each packet has arrived to the destination and add the length
        int bytes = 0;
        for (int i = 0; i < packetIds.size(); i++) {

            String[] mrs = mobileRouters.get(i);
            String[] nextMrs = nextHops.get(i);
            String lastMR = mrs[mrs.length - 1];
            int length = lenghts.get(i);
            if (lastMR.endsWith("x")) {
                lastMR = lastMR.substring(0, mrs[mrs.length - 1].indexOf("x"));
            }
            if (lastMR.equals(nextMrs[mrs.length - 1])) {
                bytes += length;
            }
        }

        return ((double) bytes / interval) * 8;
    }

    /**
     * Calculates the mean jitter in the reception of packets, considering the period of time.
     *
     * @return The jitter, in milliseconds.
     */
    public double calculateJitter(double previousJitter) {

        // Update the Jitter for every delivered packet
        long deliveredPackets = 0;
        double jitter = (previousJitter > 0 ? previousJitter : 0);
        double previousDelay = Double.MAX_VALUE;
        double cumulativeJitter = 0;
        for (int i = 0; i < packetIds.size(); i++) {

            String[] mrs = mobileRouters.get(i);
            String[] nextMrs = nextHops.get(i);
            String lastMR = mrs[mrs.length - 1];
            long srcTime = localTimes.get(i)[0];
            long destTime = localTimes.get(i)[localTimes.get(i).length - 1];
            int length = lenghts.get(i);
            if (lastMR.endsWith("x")) {
                lastMR = lastMR.substring(0, mrs[mrs.length - 1].indexOf("x"));
            }

            // If the packet has received correctly, update the values
            if (lastMR.equals(nextMrs[mrs.length - 1])) {

                deliveredPackets++;

                long delay = Math.abs(destTime - srcTime);

                if (previousDelay != Double.MAX_VALUE) {
                    //jitter = jitter + (Math.abs(delay-previousDelay) - jitter)/16; // -> Wireshark and RTP
                    jitter = Math.abs(previousDelay - delay); // -> RFC 4689
                }

                previousDelay = delay;
                cumulativeJitter += jitter;
            }
        }

        if (deliveredPackets > 0) {
            return (cumulativeJitter / deliveredPackets);
        }

        return -1;
    }

    /**
     * Gets the packets logged in the period.
     *
     * @return The number of packets.
     */
    public int getLoggedPackets() {

        return packetIds.size();
    }

    /**
     * Search a link in a set.
     */
    private MRLink searchLink(String mr1, String mr2, Vector<MRLink> mrLinks) {

        for (int i = 0; i < mrLinks.size(); i++) {

            MRLink mrLink = mrLinks.get(i);
            if (mrLink.getMr1().equals(mr1) && mrLink.getMr2().equals(mr2)) {
                return mrLink;
            }
        }

        return null;
    }

    public class MRLink {

        private String mr1;
        private String mr2;
        private int packetsInLink;
        private int packetsOk;
        private double pdr;

        public MRLink(String mr1, String mr2) {

            this.mr1 = mr1;
            this.mr2 = mr2;
            this.packetsInLink = 0;
            this.packetsOk = 0;
            this.pdr = 0;
        }

        public void clear() {

            packetsInLink = 0;
            packetsOk = 0;
            pdr = 0;
        }

        public String getMr1() {

            return mr1;
        }

        public String getMr2() {

            return mr2;
        }

        public void newPacketInLink() {

            packetsInLink++;
        }

        public void newPacketOK() {

            packetsOk++;
        }

        public double getPdr() {

            if (packetsInLink > 0) {
                return ((double) packetsOk / packetsInLink);
            } else {
                return -1;
            }
        }

        public Object clone() {

            MRLink copy = new MRLink(mr1, mr2);
            copy.packetsInLink = 0;
            copy.packetsOk = 0;
            copy.pdr = 0;

            return copy;
        }

        public boolean equals(Object o) {

            if (!(o instanceof MRLink)) {
                return false;
            }

            MRLink mrLink = (MRLink) o;

            if (mrLink.getMr1().equals(mr1) && mrLink.getMr2().equals(mr2)) {
                return true;
            } else {
                return false;
            }
        }
    }
}
