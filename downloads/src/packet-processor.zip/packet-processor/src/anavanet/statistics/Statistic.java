/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet.statistics;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Vector;

/**
 * Logic to calculate statistics values for the packets emmited.
 *
 * @author Jos� Santa Lozano
 * @author Manabu Tsukada
 */
public class Statistic {

    /**
     * Calculate statistics about IPerf packets transmitted.
     *
     * @param packetIds Packet identifiers.
     * @param mobileRouters Path followed by packets among MR.
     * @param localTimes Timestamp for each packet in each MR.
     * @param nextHops Next hop for the packet in each MR.
     * @param lengths The length of the logged packets.
     * @param gpsUtcTimes UTC Time for each GPS fix.
     * @param gpsLocalTimes Local time of each GPS fix in each MR.
     * @param latitudes Latitude of the MR positions.
     * @param longitudes Longitude of the MR positions.
     * @param distances Distances between each pair of MRs.
     * @param mrIds Identifier of all MRs.
     */
    public static StatisticInfo[] calculateStatistics(long[] packetIds, Vector<String[]> mobileRouters,
            Vector<long[]> localTimes, Vector<String[]> nextHops, int[] lengths, long[] gpsUtcTimes, Vector<long[]> gpsLocalTimes, Vector<double[]> latitudes,
            Vector<double[]> longitudes, Vector<double[]> speeds, Vector<double[]> distances,  Vector<String> mrIds,
            Vector<long[]> BULocalTime, int[] NEMOStatuses) {

        System.out.print("00%");

        // Calculate statistics for each UTC-GPS second
        int index = 0;
        StatisticInfo[] statisticInfos = new StatisticInfo[gpsUtcTimes.length];
        PacketStatistic.MRLink[] mrLinks = null;
        double jitter = 0;

        for (int i = 0; i < gpsUtcTimes.length; i++) {
            // Update % completed each 1%
            if (gpsUtcTimes.length != 0 || (i % (gpsUtcTimes.length / 100)) == 0) {
                int perc = (i * 100) / gpsUtcTimes.length;
                if (perc < 10) {
                    System.out.print("\b\b");
                } else {
                    System.out.print("\b\b\b");
                }
                System.out.print(perc + "%");
            }

            // Create a statistics object for the current second
            PacketStatistic packetStatistic = new PacketStatistic(latitudes.get(i), longitudes.get(i),
                    distances.get(i), speeds.get(i));

            // Get the local time of the GPS fix in the first MR
            long srcGpsLocalTime = gpsLocalTimes.get(i)[0];

            // Take the information about packets in the current GPS second
            for (; index < packetIds.length; index++) {
                long srcPacketLocalTime = localTimes.get(index)[0];
                if ((srcGpsLocalTime - 1000) <= srcPacketLocalTime && srcPacketLocalTime < srcGpsLocalTime) {
                    packetStatistic.addPacketInfo(packetIds[index], mobileRouters.get(index),
                            localTimes.get(index), nextHops.get(index), lengths[index]);
                } else if (srcPacketLocalTime >= srcGpsLocalTime) {
                    break;
                }
            }

            // Compute statistics for the period
            // pdr is no longer necessary in V2I, in the case that there are multiple APs
            //            double pdr = 0;
            double pdr = packetStatistic.calculatePDR();

            double rtt = packetStatistic.calculateRTT();
            int loggedPackets = packetStatistic.getLoggedPackets();
            mrLinks = packetStatistic.calculatePDRByLink(mrLinks);
            int bytes = packetStatistic.calculateReceivedBytes();
            double bandwidth = packetStatistic.calculateBandwidth(1);
            jitter = packetStatistic.calculateJitter(jitter);

            int NEMO_status = 0;
            if (BULocalTime != null) {
                for (int m = 0; m < NEMOStatuses.length; m++) {
                    if ((srcGpsLocalTime - 1000) <= BULocalTime.get(m)[0] && BULocalTime.get(m)[0] < srcGpsLocalTime) {
                        // NEMO_status recorded in the second.
//                    System.out.println("NEMOStatus == " + NEMOStatuses[m]);
//                    System.out.println("BULocalTime == " + BULocalTime.get(m)[0] + "srcGpsLocalTime == "+ srcGpsLocalTime);
                        NEMO_status = NEMOStatuses[m];
                    }
                }
            }

            // Create a new statitistic wrapper with the results of the period
            statisticInfos[i] = new StatisticInfo(gpsUtcTimes[i], srcGpsLocalTime, mrIds.toArray(new String[0]),
                    latitudes.get(i), longitudes.get(i), speeds.get(i), distances.get(i),
                    pdr, rtt, mrLinks, bytes, bandwidth, jitter, loggedPackets, NEMO_status);
        }

        // Put the same link names in all the statistics
        for (int i = 0; i < statisticInfos.length; i++) {
            statisticInfos[i].mergeLinks(mrLinks);
        }

        System.out.print("\b\b\b");
        System.out.println("\tDone");

        System.out.println("statisticInfos.length ==" + statisticInfos.length);

        return statisticInfos;
    }
}
