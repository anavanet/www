/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet.packettrace;

import anavanet.gpsproc.GPSProcessorException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * This class contains useful methods for processing dump files, in order to trace
 * emmited packets.
 * @author Jos� Santa Lozano
 * @author Manabu Tsukada
 *
 */
public class PacketTracer {

    // Size of IPERF packet size
    // When iperf with 1300 Bites, it will be 1442 by adding 142 bits of C2C NET header
    // GN6 == 1444 (old) // new == 1432
    private static final int IPERF_PACKET_SIZE = 1432;
    // Internal identifier for UDP Iperf packets
    private static final int IPERF_PACKET = 0;
    // Internal identifier for ICMP Echo Request packets
    private static final int PING_REQ_PACKETS = 1;
    // Internal identifier for ICMP Echo Reply packets
    private static final int PING_REP_PACKETS = 2;
    // Internal identifier for Binding Update
    private static final int BU_PACKETS = 5;
    // Internal identifier for Binding Acknowlegement
    private static final int BA_PACKETS = 6;
    // Difference between Madrid/Paris time and UTC time, in hours // Summer time =-1, Winter =-2 // -23 for C2C // 0 for ITSNET
    private static final int DIFF_UTC_TIME = 0;
    // Corrector for generating a different ID for reply ICMP hello packets
    private static final int PING_REP_ID_CORRECTOR = 5000000;
    // Object fields
    private Vector<PacketInfo> packetInfos = null;
    private Hashtable<Long, PacketInfo> packetHashtable = null;
    private File file = null;
    private long refDate;

    /**
     * Creates a new Packet Tracer.
     *
     * @param file The dump file.
     * @param refDate Reference date the mobile router. Dump files does not contain the year, month and day. In Java milliseconds.
     */
    public PacketTracer(File file, long refDate) {

        this.file = file;
        this.refDate = refDate;

        packetInfos = new Vector<PacketInfo>();
        packetHashtable = new Hashtable();
    }

    /**
     * Gets the wrappers of the processed packets.
     *
     * @return The packet wrappers.
     */
    public PacketInfo[] getPacketInfos() {

        return packetInfos.toArray(new PacketInfo[0]);
    }

    /**
     * Gets the wrappers of the processed packets in a hash table, indexed by packet id.
     *
     * @return The packet wrappers.
     */
    public Hashtable<Long, PacketInfo> getPacketHashtable() {

        return packetHashtable;
    }

    /**
     * Process a dump file, in order to extract traceable packets.
     */
    public void processDumpLog() throws PacketTracerException {

        BufferedReader in = null;
        try {

            // Access the file
            in = new BufferedReader(new FileReader(file));

        } catch (IOException e) {

            throw new PacketTracerException("I/O error: " + e.getMessage());
        }

        // Process log lines
        PacketInfo packetInfo = null;
        while ((packetInfo = getNewPacket(in, refDate)) != null) {

            // Check if the packet had bee logged before
            PacketInfo previousPacketInfo = packetHashtable.get(packetInfo.getId());
            if (previousPacketInfo == null) {

                // Save the packet
                packetInfos.add(packetInfo);
                packetHashtable.put(packetInfo.getId(), packetInfo);
            } // If the packet were logged previously...
            else {

                // Save the new link used to transmit the packet
                previousPacketInfo.addSrcMACAddress(packetInfo.getSrcMACAddresses().get(0));
                previousPacketInfo.addDestMACAddress(packetInfo.getDestMACAddresses().get(0));
                previousPacketInfo.addLocalTime(packetInfo.getLocalTime());
            }

            // TCP logs are not analysed
            if (packetInfo.getType() == packetInfo.TYPE_TCP) {
                PacketInfo[] result = new PacketInfo[1];
                result[0] = packetInfo;
                break;
            }
        }
    }

    /**
     * Process a dump file, in order to extract traceable packets with C2C NET header.
     */
    public void C2cnetProcessDumpLog() throws PacketTracerException {

        BufferedReader in = null;
        try {

            // Access the file
            in = new BufferedReader(new FileReader(file));

        } catch (IOException e) {

            throw new PacketTracerException("I/O error: " + e.getMessage());
        }

        // Process log lines
        PacketInfo packetInfo = null;
        while ((packetInfo = getNewC2cnetPacket(in, refDate)) != null) {

            // Check if the packet had bee logged before
            PacketInfo previousPacketInfo = packetHashtable.get(packetInfo.getId());
            if (previousPacketInfo == null) {

                // Save the packet
                packetInfos.add(packetInfo);
                packetHashtable.put(packetInfo.getId(), packetInfo);

                // If the packet were logged previously...
            } else {
                // Save the new link used to transmit the packet
                previousPacketInfo.addSrcMACAddress(packetInfo.getSrcMACAddresses().get(0));
                previousPacketInfo.addDestMACAddress(packetInfo.getDestMACAddresses().get(0));
                previousPacketInfo.addLocalTime(packetInfo.getLocalTime());
            }
            // TCP logs are not analysed
            if (packetInfo.getType() == packetInfo.TYPE_TCP) {
                PacketInfo[] result = new PacketInfo[1];
                result[0] = packetInfo;
                break;
            }
        }

    }
    /**
     * Process a dump file, in order to extract traceable packets with GN6 header.
     */
    public void gn6ProcessDumpLog() throws PacketTracerException {

        BufferedReader in = null;
        try {

            // Access the file
            in = new BufferedReader(new FileReader(file));

        } catch (IOException e) {

            throw new PacketTracerException("I/O error: " + e.getMessage());
        }
        // Process log lines
        PacketInfo packetInfo = null;
        while ((packetInfo = getNewGN6Packet(in, refDate)) != null) {

            // Check if the packet had bee logged before
            PacketInfo previousPacketInfo = packetHashtable.get(packetInfo.getId());
            if (previousPacketInfo == null) {

                // Save the packet
                packetInfos.add(packetInfo);
                packetHashtable.put(packetInfo.getId(), packetInfo);

                // If the packet were logged previously...
            } else {
                // Save the new link used to transmit the packet
                previousPacketInfo.addSrcMACAddress(packetInfo.getSrcMACAddresses().get(0));
                previousPacketInfo.addDestMACAddress(packetInfo.getDestMACAddresses().get(0));
                previousPacketInfo.addLocalTime(packetInfo.getLocalTime());
            }
            // TCP logs are not analysed
            if (packetInfo.getType() == packetInfo.TYPE_TCP) {
                PacketInfo[] result = new PacketInfo[1];
                result[0] = packetInfo;
                break;
            }
        }

    }

    /**
     * Trace UDP packets from IPerf along mobile routers.
     *
     * @param sentPackets Set of packets sent from the source MR.
     * @param packetHashtables Logged packets in each MR, sorted in a hashtable.
     * @param mrIds Identifiers for each MR, in the same order as dumpFiles. First one is source MR.
     * @param mrMacs MAC addresses for each MR, in the same order as dumpFiles. First one is source MR.
     * @return Trace informati�n for each UDP Iperf packet sent from the source.
     */
    public static PacketTrace[] traceIperfPackets(PacketInfo[] sentPackets, Hashtable[] packetHashtables, Vector<String> mrIds, Vector<String> mrMacs, int destMRNumFromLast) {
        System.out.println("Be careful!!!!! IPERF_PACKET_SIZE == " + IPERF_PACKET_SIZE);

        Vector<PacketTrace> packetTraces = tracePackets(sentPackets, packetHashtables, mrIds.toArray(new String[0]), mrMacs.toArray(new String[0]), IPERF_PACKET, destMRNumFromLast);

        return packetTraces.toArray(new PacketTrace[0]);
    }

    /**
     * Trace PING packets along mobile routers, searching for echo request and returning echo replies.
     *
     * @param sentPacketsAtSrcMR Set of packets sent from the source MR.
     * @param setnPacketsAtDestMR Set of packets sent from the destination MR.
     * @param packetHashtables Logged packets in each MR, sorted in a hashtable.
     * @param mrIds Identifiers for each MR, in the same order as dumpFiles. First one is source MR.
     * @param mrMacs MAC addresses for each MR, in the same order as dumpFiles. First one is source MR.
     * @return Trace informati�n for each PING packet sent from the source, with the path towards the destination first,
     * and then the coming back path.
     */
    public static PacketTrace[] traceTwoWayPackets(PacketInfo[] sentPacketsAtSrcMR, Vector<PacketInfo[]> sentPacketsAtDestMRs,
            Hashtable[] packetHashtables, Vector<String> mrIds, Vector<String> mrMacs, int destMRNumFromLast, int protocol) {

        /**
         * Trace PING request packets
         */
        Vector<PacketTrace> reqPacketTraces = null;
        if (protocol == PacketInfo.TYPE_ICMP_REQ) {
            System.out.println("\tTracing ICMP Request packets sent at source MR...");
            reqPacketTraces = tracePackets(sentPacketsAtSrcMR, packetHashtables, mrIds.toArray(new String[0]),
                    mrMacs.toArray(new String[0]), PING_REQ_PACKETS, destMRNumFromLast);
        } else if (protocol == PacketInfo.TYPE_NEMO_BU) {
            System.out.println("\tTracing NEMO Binding Update packets sent at source MR...");
            reqPacketTraces = tracePackets(sentPacketsAtSrcMR, packetHashtables, mrIds.toArray(new String[0]),
                    mrMacs.toArray(new String[0]), BU_PACKETS, destMRNumFromLast);
        }
        // If the ICMP Req has arrived correctly to the destination MR, remove the end trace (ej. MR3(MR3), and the arrival of
        // duplicated packets (ej. MR3(MR3) MR3(MR3))

        for (PacketTrace packetTrace : reqPacketTraces) {
            String[] mrs = packetTrace.getMobileRouters();
            String[] nextMrs = packetTrace.getNextHops();
            long[] localTimes = packetTrace.getLocalTimes();

            while (mrs[mrs.length - 1].equals(nextMrs[nextMrs.length - 1])) {

                String[] newMrs = new String[mrs.length - 1];
                String[] newNextMrs = new String[nextMrs.length - 1];
                long[] newLocalTimes = new long[nextMrs.length - 1];
                for (int i = 0; i < newMrs.length; i++) {
                    newMrs[i] = mrs[i];
                    newNextMrs[i] = nextMrs[i];
                    newLocalTimes[i] = localTimes[i];
                }

                mrs = newMrs;
                nextMrs = newNextMrs;
                localTimes = newLocalTimes;
            }
            packetTrace.setMobileRouters(mrs);
            packetTrace.setNextHops(nextMrs);
            packetTrace.setLocalTimes(localTimes);
        }


        System.out.println("\tDone");

        /**
         * Trace PING reply packets from destination to source
         */
//        System.out.println("\tTracing ICMP Reply packets sent from destination MR...");
        // Invert the path of packets
        for (int dest = 0; dest < destMRNumFromLast; dest++) {
            Hashtable[] invPacketHashtables = new Hashtable[packetHashtables.length];
            Vector<String> invMrIds = new Vector<String>();
            Vector<String> invMrMacs = new Vector<String>();

//            for (int i = packetHashtables.length - 1; i >= 0; i--) {
            // Take the soruce node address when there are multiple destination
            int n = packetHashtables.length - destMRNumFromLast + dest;
            int hashindex = 0;
            invPacketHashtables[hashindex] = packetHashtables[n];
            hashindex++;
            invMrIds.add(mrIds.get(n));
            invMrMacs.add(mrMacs.get(n));
            // the order is same as usual reverse path except for the
            for (n = packetHashtables.length - 1; n >= 0; n--) {
                if (n != packetHashtables.length - destMRNumFromLast + dest) {
                    invPacketHashtables[hashindex] = packetHashtables[n];
                    invMrIds.add(mrIds.get(n));
                    invMrMacs.add(mrMacs.get(n));
                    hashindex++;
                }
            }

            Vector<PacketTrace> repPacketTraces = null;
//            System.out.println(" ================= " + dest + " ================= ");
            // Trace packets
            // In reverse path, the destination is source MR only, so destMRNumFromLast = 1.
            if (protocol == PacketInfo.TYPE_ICMP_REQ) {
                System.out.println("\tTracing ICMP Request packets sent at source MR...[" + dest + "]");
                repPacketTraces = tracePackets(sentPacketsAtDestMRs.get(dest), invPacketHashtables,
                        invMrIds.toArray(new String[0]), invMrMacs.toArray(new String[0]), PING_REP_PACKETS, 1 /*destMRNumFromLast*/);
                System.out.println("\tDone");
                System.out.println("\tCreate complete routes for PINGs...");
            } else if (protocol == PacketInfo.TYPE_NEMO_BU) {
                System.out.println("\tTracing NEMO Binding Acknowledge packets sent at source MR...[" + dest + "]");
                repPacketTraces = tracePackets(sentPacketsAtDestMRs.get(dest), invPacketHashtables,
                        invMrIds.toArray(new String[0]), invMrMacs.toArray(new String[0]), BA_PACKETS, 1 /*destMRNumFromLast*/);
                                System.out.println("\tDone");
                System.out.println("\tCreate complete routes for NEMO Signaling...");
            }

            /**
             * Create complete routes for PINGs.
             */
            System.out.print("00%");

            // Study each ICMP echo request
            int margin = repPacketTraces.size(); // Margin for search for packets out of order
            int j = 0, index = 0;
            for (int i = 0; i < reqPacketTraces.size(); i++) {

                PacketTrace reqPacketTrace = reqPacketTraces.get(i);

                // Update % completed each 1%
                if (reqPacketTraces.size() != 0 || (i % (reqPacketTraces.size() / 100)) == 0) {
                    int perc = (i * 100) / reqPacketTraces.size();
                    if (perc < 10) {
                        System.out.print("\b\b");
                    } else {
                        System.out.print("\b\b\b");
                    }
                    System.out.print(perc + "%");
                }

                // Search for the reply according to the request
                for (j = (index > margin) ? (index - margin) : 0;
                        j < repPacketTraces.size()
                        && repPacketTraces.get(j).getPacketInfo().getId() != reqPacketTrace.getPacketInfo().getId() + PING_REP_ID_CORRECTOR;
                        j++);

                // Check if the reply has been found, add the rest of route to the PING
                if (j < repPacketTraces.size()) {
                    // Complete the route
                    PacketTrace repPacketTrace = repPacketTraces.get(j);
                    String[] mrs = repPacketTrace.getMobileRouters();
                    long[] times = repPacketTrace.getLocalTimes();
                    String[] nextHops = repPacketTrace.getNextHops();
                    if (mrs.length == 0) {
                        continue;
                    }
                    reqPacketTrace.addTrace(mrs[0], times[0], nextHops[0] + "x"); // First node is not marked to join with the contrary route

                    for (int k = 1; k < mrs.length - 1; k++) {
//                        System.out.println("mrs[" + k + "]==" + mrs[k].toString() + " times[" + k + "]==" + times[k] + " nextHop[" + k + "] ==" + nextHops[k]);
                        if (!mrs[k].equals(nextHops[k])) // Remove multiple arrivals of packets
                        {
                            reqPacketTrace.addTrace(mrs[k] + "x", times[k], nextHops[k] + "x"); // Inverse route of PINGs are marked
                        }
                    }

                    if (mrs.length > 1) {
                        if (mrs[mrs.length - 1].equals(nextHops[mrs.length - 1])) {
                            reqPacketTrace.addTrace(mrs[mrs.length - 1] + "x", times[mrs.length - 1], nextHops[mrs.length - 1]); // Last node is not marked to join with the initial node, if the packet is reply arrives
                        } else {
                            reqPacketTrace.addTrace(mrs[mrs.length - 1] + "x", times[mrs.length - 1], nextHops[mrs.length - 1] + "x");
                        }
                    }

                    // Save the index to start searching the next cicle
                    index = j;
                }
            }

        }

        System.out.print("\b\b\b");
        System.out.println("\tDone");

        // Return the result
        return reqPacketTraces.toArray(new PacketTrace[0]);
    }

    /**
     * Extract a new packet with C2C NET header from the log file.
     *
     * @param in The input from the file.
     * @param refDate The reference date.
     * @return A wrapper object wit hte new packet.
     */
    @SuppressWarnings("static-access")
    private static PacketInfo getNewC2cnetPacket(BufferedReader in, long refDate) throws PacketTracerException {

        try {

            String line = null;
            PacketInfo packetInfo = null;
            String srcIpv6Address = "";
            String dstIpv6Address = "";
            int type = 0;
            boolean nemo_tun_mode = false;  // if true, see inner address


            while ((line = in.readLine()) != null) {

                if (!line.startsWith("\t")) {
                    srcIpv6Address = "";
                    dstIpv6Address = "";
                    // Process new packet
                    packetInfo = processGeneralInfoLineForC2cnet(line, refDate);
                } // Data line with information about the source and destination MAC addresses
                else if (line.startsWith("\t0x0000") && packetInfo != null) {

                    String srcMACAddress = processSrcMACLine(line);
                    packetInfo.addSrcMACAddress(srcMACAddress);
                    String destMACAddress = processDestMACLine(line);
                    packetInfo.addDestMACAddress(destMACAddress);

                } // Get IPv6 source address
                else if (line.startsWith("\t0x0060") && packetInfo != null) {
                    // Determinate UDP, TCP, ICMP req/repy or NEMO
                    type = processTypeLine(line);
                    packetInfo.setType(type);

                    if (type != packetInfo.TYPE_NEMO_TUN) {    // if it is NEMO tunnel, take inside IP address
                        srcIpv6Address = processSrcAddressLine1(line);
                    } else {
                        nemo_tun_mode = true;
                    }
                } // Get IPv6 destination address
                else if (line.startsWith("\t0x0070") && packetInfo != null && nemo_tun_mode == false) {
                    srcIpv6Address += processSrcAddressLine2(line);
                    packetInfo.setSrcAddress(srcIpv6Address);
                    dstIpv6Address = processDestAddressLine1(line);
                } else if (line.startsWith("\t0x0080") && packetInfo != null) {
                    if (nemo_tun_mode == false) {    // if it is not NEMO
                        dstIpv6Address += processDestAddressLine2(line);
                        packetInfo.setDestAddress(dstIpv6Address);
                        // Process port only when TYPE_UDP or TYPE_TCP
                        if (packetInfo.getType() == packetInfo.TYPE_UDP || packetInfo.getType() == packetInfo.TYPE_TCP) {
                            packetInfo.setSrcPort(processSrcPortLine(line));
                            packetInfo.setDestPort(processDestPortLine(line));
                        }
                        // check request or reply, when TYPE_ICMP_REQ
                        if (packetInfo.getType() == packetInfo.TYPE_ICMP_REQ) {
                            packetInfo.setType(processIcmpTypeLine(line));
                            if (packetInfo.getType() == packetInfo.TYPE_ICMP_REQ) {
                                packetInfo.setId(processIcmpSequenceLine(line));
//                            System.out.println("  Request=" + packetInfo.getId());
                            }
                            // check request or reply, when TYPE_ICMP_REP
                            if (packetInfo.getType() == packetInfo.TYPE_ICMP_REP) {
                                packetInfo.setId(processIcmpSequenceLine(line) + PING_REP_ID_CORRECTOR); // Start a different numeration for response ICMP, to make the ID different
//                            System.out.println("  Reply=" + packetInfo.getId());
                            }
                            return packetInfo;
                        }

                    } else { // if NEMO tunnel, see inner info
                        if (packetInfo.getType() == packetInfo.TYPE_NEMO_TUN) {
                            type = processTypeLineAfterNEMO(line);
                            packetInfo.setType(type);
                            srcIpv6Address = processSrcAddressLineNEMO1(line);
                        }
                    }

                } // Data line with information about the ID of the packet
                else if (line.startsWith("\t0x0090") && packetInfo != null) {
                    if (nemo_tun_mode == false) {    // if it is not NEMO
                        if (packetInfo.getType() == packetInfo.TYPE_UDP && packetInfo.getLength() == IPERF_PACKET_SIZE) {
                            String id = processIdDataLine(line);
                            packetInfo.setId(Long.parseLong(id, 16));
                            return packetInfo;
                        }

                    } else {   // NEMO
                        srcIpv6Address += processSrcAddressLineNEMO2(line);
                        packetInfo.setSrcAddress(srcIpv6Address);
//                        System.out.println("srcIpv6Address == " + srcIpv6Address);
                        dstIpv6Address = processDestAddressLineNEMO1(line);
                    }
                } else if (line.startsWith("\t0x00a0") && packetInfo != null) {
                    if (nemo_tun_mode == false) {
                        if (type == packetInfo.TYPE_NEMO_BU) {
                            packetInfo.setId(processBUSequence(line));
//                            System.out.println("  BU=" + packetInfo.getId());
                            return packetInfo;
                        }
                        if (type == packetInfo.TYPE_NEMO_BA) {
                            packetInfo.setId(processBASequence(line) + PING_REP_ID_CORRECTOR);
//                            System.out.println("  BA=" + packetInfo.getId());
                            return packetInfo;
                        }
                    } else { // NEMO tunnel inside
                        dstIpv6Address += processDestAddressLineNEMO2(line);
//                        System.out.println("dstIpv6Address == " + dstIpv6Address);
                        packetInfo.setDestAddress(dstIpv6Address);
                        // Process port only when TYPE_UDP or TYPE_TCP XXX
                        if (packetInfo.getType() == packetInfo.TYPE_UDP || packetInfo.getType() == packetInfo.TYPE_TCP) {
                            packetInfo.setSrcPort(processSrcPortLineAfterNEMO(line));
//                            System.out.println("processSrcPortLineAfterNEMO port = " + packetInfo.getSrcPort());
                        }
                        // check request or reply, when TYPE_ICMP_REQ
                        if (packetInfo.getType() == packetInfo.TYPE_ICMP_REQ) {
                            // determine TYPE_ICMP_REQ or TYPE_ICMP_REP
                            packetInfo.setType(processIcmpTypeLineAfterNEMO(line));
                        }

                    }
                } else if (line.startsWith("\t0x00b0") && packetInfo != null && nemo_tun_mode == true) {
                    if (packetInfo.getType() == packetInfo.TYPE_ICMP_REQ) {
                        packetInfo.setId(processIcmpSequenceLineAfterNEMO(line));
//                        System.out.println("  Request=" + packetInfo.getId());
                        return packetInfo;
                    } else if (packetInfo.getType() == packetInfo.TYPE_ICMP_REP) {
                        packetInfo.setId(processIcmpSequenceLineAfterNEMO(line) + PING_REP_ID_CORRECTOR); // Start a different numeration for response ICMP, to make the ID different
//                        System.out.println("  Reply=" + packetInfo.getId());
                        return packetInfo;
                    } else if (packetInfo.getType() == packetInfo.TYPE_TCP) {
                        packetInfo.setDestPort(processDestPortLineAfterNEMO(line));
//                        System.out.println("processDestPortLineAfterNEMO port = " + packetInfo.getDestPort());
                        return packetInfo;
                    } else if (packetInfo.getType() == packetInfo.TYPE_UDP) {
                        packetInfo.setDestPort(processDestPortLineAfterNEMO(line));
                        packetInfo.setId(processUDPSequenceLineAfterNEMO(line));
                        return packetInfo;
                    }
                }
            }

            return null;

        } catch (IOException e) {
            throw new PacketTracerException("Error processing dump file: " + e);
        }
    }
    /**
     * Extract a new packet with GN header from the log file.
     *
     * @param in The input from the file.
     * @param refDate The reference date.
     * @return A wrapper object wit the new packet.
     */
    @SuppressWarnings("static-access")
    private static PacketInfo getNewGN6Packet(BufferedReader in, long refDate) throws PacketTracerException {
/* GN6 header (PING6 request / reply)
 * 17:43:38.983279 6.0 Mb/s [bit 15] CF +QoS 00:1b:b1:b1:8a:a3 > 00:1b:b1:b5:e6:c4 SNAP Unnumbered, ui, Flags [Command], length 200
        0x0000:  0000 0d00 0480 0200 0c00 0000 0088 003c
        0x0010:  0000 1bb1 b18a a300 1bb1 b5e6 c4ff ffff
        0x0020:  ffff ffb0 3d00 00aa aa03 0000 0007 0703
        0x0030:  2000 0000 683a 0a14 0000 1bb1 b5e6 c455
        0x0040:  a528 101d 1c09 be01 40ac b400 0900 0000
        0x0050:  8f00 0000 40f2 0014 0000 1bb1 b5e6 c455
        0x0060:  a528 101d 1c09 be01 40ac b400 0900 0000
        0x0070:  8f00 0014 0000 1bb1 b18a a300 0000 001d
        0x0080:  1c09 4a01 40af c460 0000 0000 403a 4020
        0x0090:  0106 6030 13f2 0002 1bb1 fffe b5e6 c420
        0x00a0:  0106 6030 13f3 0000 0000 0000 0000 0180
        0x00b0:  00db be5b 1800 2ce9 7333 8d00 0000 0000
        0x00c0:  0000 0000 0000 0000 0000 0000 0000 0000
        0x00d0:  0000 0000 0000 0000 0000 0000 0000 0000
        0x00e0:  0000 0000 0000 0000 0000 0000 0000 00
17:43:38.989889 3135846634us tsft 6.0 Mb/s 5900 MHz 11a -69dB signal antenna 2 [bit 14] CF +QoS 00:1b:b1:b5:e6:c4 > 00:1b:b1:b1:8a:a3 SNAP Unnumbered, ui, Flags [Command], length 204
        0x0000:  0000 1a00 2f48 0000 ea38 e9ba 0000 0000
        0x0010:  100c 0c17 4001 bb02 0000 8800 3c00 001b
        0x0020:  b1b5 e6c4 001b b1b1 8aa3 ffff ffff ffff
        0x0030:  10e2 0000 aaaa 0300 0000 0707 0320 0000
        0x0040:  0068 3a0a 1400 001b b1b1 8aa3 0000 0000
        0x0050:  1d1c 094a 0140 afc4 0000 0384 005f 0000
        0x0060:  0084 f200 1400 001b b1b1 8aa3 0000 0000
        0x0070:  1d1c 094a 0140 afc4 0000 0384 005f 0000
        0x0080:  1400 001b b1b5 e6c4 55a5 2810 1d1c 09be
        0x0090:  0140 acb4 6000 0000 0040 3a40 2001 0660
        0x00a0:  3013 f300 0000 0000 0000 0001 2001 0660
        0x00b0:  3013 f200 021b b1ff feb5 e6c4 8100 dabe
        0x00c0:  5b18 002c e973 338d 0000 0000 0000 0000
        0x00d0:  0000 0000 0000 0000 0000 0000 0000 0000
        0x00e0:  0000 0000 0000 0000 0000 0000 0000 0000
        0x00f0:  0000 0000 0000 0000 0000 0000 bb78 81b2
 */
        try {

            String line = null;
            PacketInfo packetInfo = null;
            String srcIpv6Address = "";
            String dstIpv6Address = "";
            int type = 0;
            boolean nemo_tun_mode = false;  // if true, see inner address

            while ((line = in.readLine()) != null) {

                if (!line.startsWith("\t")) {
                    srcIpv6Address = "";
                    dstIpv6Address = "";
                    // Process new packet
                    packetInfo = processGeneralInfoLineForC2cnet(line, refDate);
                } // Data line with information about the source and destination MAC addresses
                else if (line.startsWith("\t0x0000") && packetInfo != null) {

                    String srcMACAddress = processSrcMACLine(line);
                    packetInfo.addSrcMACAddress(srcMACAddress);
                    String destMACAddress = processDestMACLine(line);
                    packetInfo.addDestMACAddress(destMACAddress);

                } // Get IPv6 source address
                else if (line.startsWith("\t0x0060") && packetInfo != null) {
                    // Determinate UDP, TCP, ICMP req/repy or NEMO

                    type = processTypeLine(line);
                    packetInfo.setType(type);

                    if (type != packetInfo.TYPE_NEMO_TUN) {    // if it is NEMO tunnel, take inside IP address
                        srcIpv6Address = processSrcAddressLine1(line);
                    } else {
                        nemo_tun_mode = true;
                    }
                } // Get IPv6 destination address
                else if (line.startsWith("\t0x0070") && packetInfo != null && nemo_tun_mode == false) {
                    srcIpv6Address += processSrcAddressLine2(line);
                    packetInfo.setSrcAddress(srcIpv6Address);
                    dstIpv6Address = processDestAddressLine1(line);
                } else if (line.startsWith("\t0x0080") && packetInfo != null) {
                    if (nemo_tun_mode == false) {    // if it is not NEMO
                        dstIpv6Address += processDestAddressLine2(line);
                        packetInfo.setDestAddress(dstIpv6Address);
                        // Process port only when TYPE_UDP or TYPE_TCP
                        if (packetInfo.getType() == packetInfo.TYPE_UDP || packetInfo.getType() == packetInfo.TYPE_TCP) {
                            packetInfo.setSrcPort(processSrcPortLine(line));
                            packetInfo.setDestPort(processDestPortLine(line));
                        }
                        // check request or reply, when TYPE_ICMP_REQ
                        if (packetInfo.getType() == packetInfo.TYPE_ICMP_REQ) {
                            packetInfo.setType(processIcmpTypeLine(line));
                            if (packetInfo.getType() == packetInfo.TYPE_ICMP_REQ) {
                                packetInfo.setId(processIcmpSequenceLine(line));
//                            System.out.println("  Request=" + packetInfo.getId());
                            }
                            // check request or reply, when TYPE_ICMP_REP
                            if (packetInfo.getType() == packetInfo.TYPE_ICMP_REP) {
                                packetInfo.setId(processIcmpSequenceLine(line) + PING_REP_ID_CORRECTOR); // Start a different numeration for response ICMP, to make the ID different
//                            System.out.println("  Reply=" + packetInfo.getId());
                            }
                            return packetInfo;
                        }

                    } else { // if NEMO tunnel, see inner info
                        if (packetInfo.getType() == packetInfo.TYPE_NEMO_TUN) {
                            type = processTypeLineAfterNEMO(line);
                            packetInfo.setType(type);
                            srcIpv6Address = processSrcAddressLineNEMO1(line);
                        }
                    }

                } // Data line with information about the ID of the packet
                else if (line.startsWith("\t0x0090") && packetInfo != null) {
                    if (nemo_tun_mode == false) {    // if it is not NEMO
                        if (packetInfo.getType() == packetInfo.TYPE_UDP && packetInfo.getLength() == IPERF_PACKET_SIZE) {
                            String id = processIdDataLine(line);
                            packetInfo.setId(Long.parseLong(id, 16));
                            return packetInfo;
                        }

                    } else {   // NEMO
                        srcIpv6Address += processSrcAddressLineNEMO2(line);
                        packetInfo.setSrcAddress(srcIpv6Address);
//                        System.out.println("srcIpv6Address == " + srcIpv6Address);
                        dstIpv6Address = processDestAddressLineNEMO1(line);
                    }
                } else if (line.startsWith("\t0x00a0") && packetInfo != null) {
                    if (nemo_tun_mode == false) {
                        if (type == packetInfo.TYPE_NEMO_BU) {
                            packetInfo.setId(processBUSequence(line));
//                            System.out.println("  BU=" + packetInfo.getId());
                            return packetInfo;
                        }
                        if (type == packetInfo.TYPE_NEMO_BA) {
                            packetInfo.setId(processBASequence(line) + PING_REP_ID_CORRECTOR);
//                            System.out.println("  BA=" + packetInfo.getId());
                            return packetInfo;
                        }
                    } else { // NEMO tunnel inside
                        dstIpv6Address += processDestAddressLineNEMO2(line);
//                        System.out.println("dstIpv6Address == " + dstIpv6Address);
                        packetInfo.setDestAddress(dstIpv6Address);
                        // Process port only when TYPE_UDP or TYPE_TCP XXX
                        if (packetInfo.getType() == packetInfo.TYPE_UDP || packetInfo.getType() == packetInfo.TYPE_TCP) {
                            packetInfo.setSrcPort(processSrcPortLineAfterNEMO(line));
//                            System.out.println("processSrcPortLineAfterNEMO port = " + packetInfo.getSrcPort());
                        }
                        // check request or reply, when TYPE_ICMP_REQ
                        if (packetInfo.getType() == packetInfo.TYPE_ICMP_REQ) {
                            // determine TYPE_ICMP_REQ or TYPE_ICMP_REP
                            packetInfo.setType(processIcmpTypeLineAfterNEMO(line));
                        }

                    }
                } else if (line.startsWith("\t0x00b0") && packetInfo != null && nemo_tun_mode == true) {
                    if (packetInfo.getType() == packetInfo.TYPE_ICMP_REQ) {
                        packetInfo.setId(processIcmpSequenceLineAfterNEMO(line));
//                        System.out.println("  Request=" + packetInfo.getId());
                        return packetInfo;
                    } else if (packetInfo.getType() == packetInfo.TYPE_ICMP_REP) {
                        packetInfo.setId(processIcmpSequenceLineAfterNEMO(line) + PING_REP_ID_CORRECTOR); // Start a different numeration for response ICMP, to make the ID different
//                        System.out.println("  Reply=" + packetInfo.getId());
                        return packetInfo;
                    } else if (packetInfo.getType() == packetInfo.TYPE_TCP) {
                        packetInfo.setDestPort(processDestPortLineAfterNEMO(line));
//                        System.out.println("processDestPortLineAfterNEMO port = " + packetInfo.getDestPort());
                        return packetInfo;
                    } else if (packetInfo.getType() == packetInfo.TYPE_UDP) {
                        packetInfo.setDestPort(processDestPortLineAfterNEMO(line));
                        packetInfo.setId(processUDPSequenceLineAfterNEMO(line));
                        return packetInfo;
                    }
                }
            }

            return null;

        } catch (IOException e) {
            throw new PacketTracerException("Error processing dump file: " + e);
        }
    }

    /**
     * Extract a new packet from the log file.
     *
     * @param in The input from the file.
     * @param refDate The reference date.
     * @return A wrapper object wit hte new packet.
     */
    private static PacketInfo getNewPacket(BufferedReader in, long refDate) throws PacketTracerException {

        try {

            String line = null;
            PacketInfo packetInfo = null;
            while ((line = in.readLine()) != null) {

                if (!line.startsWith("\t")) {

                    // Process new packet
                    packetInfo = processGeneralInfoLine(line, refDate);
                } // Data line with information about the source and destination MAC addresses
                else if (line.startsWith("\t0x0000") && packetInfo != null) {

                    String srcMACAddress = processSrcMACLine(line);
                    packetInfo.addSrcMACAddress(srcMACAddress);
                    String destMACAddress = processDestMACLine(line);
                    packetInfo.addDestMACAddress(destMACAddress);


                    if (packetInfo.getType() == packetInfo.TYPE_ICMP_REQ
                            || packetInfo.getType() == packetInfo.TYPE_ICMP_REP
                            || packetInfo.getType() == packetInfo.TYPE_TCP) {
                        return packetInfo;
                    }
                } // Data line with information about the ID of the packet
                else if (line.startsWith("\t0x0040") && packetInfo != null) {

                    String id = processIdDataLine(line);
                    packetInfo.setId(Long.parseLong(id, 16));

                    if (packetInfo.getType() == packetInfo.TYPE_UDP && packetInfo.getLength() == IPERF_PACKET_SIZE) {
                        return packetInfo;
                    }
                }
            }

            return null;

        } catch (IOException e) {
            throw new PacketTracerException("Error processing dump file: " + e);
        }
    }

    /**
     * Process the general information line about a logged packet.
     *
     * @param line The line of text from the file.
     * @param refDate Reference date.
     * @return Returns a wrapper with the packet data.
     */
    private static PacketInfo processGeneralInfoLineForC2cnet(String line, long refDate) throws PacketTracerException {

        /**
         * Parse fields
         */
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line, " ", false);

        // Local time
        String timeS = tokenizer.nextToken();
        int hour = Integer.parseInt(timeS.substring(0, 2)) + DIFF_UTC_TIME; // Adjust time to UTC
        int min = Integer.parseInt(timeS.substring(3, 5));
        int sec = Integer.parseInt(timeS.substring(6, 8));
        int mill = Integer.parseInt(timeS.substring(9, 12));


        // Src address
        InetAddress srcAddr = null;
        // Dest address
        InetAddress destAddr = null;
        int srcPort = 0;
        int destPort = 0;

        // Protocol name and identifier (if possible)
        int type = 0;
        long id = 0;

        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();

        // Packet length except for TCP
        int length = 0;
        String lengthSS = tokenizer.nextToken();

        if (type != PacketInfo.TYPE_TCP) {
            length = Integer.parseInt(lengthSS.substring(0, lengthSS.indexOf(":")));
        }

        /**
         * Create the wrapper info object.
         */
        // Establish complete local time
        Calendar refTime = new GregorianCalendar();
        refTime.setTimeInMillis(refDate);
        Calendar localTime = (Calendar) refTime.clone();
        localTime.set(Calendar.HOUR_OF_DAY, hour);
        localTime.set(Calendar.MINUTE, min);
        localTime.set(Calendar.SECOND, sec);
        localTime.set(Calendar.MILLISECOND, mill);

        // Create IP src and dest address

        // Create wrapper object
        PacketInfo packetInfo = new PacketInfo(srcAddr, destAddr, srcPort, destPort, type, length, id, localTime.getTimeInMillis());
        packetInfo.addLocalTime(localTime.getTimeInMillis());

        return packetInfo;
    }

    /**
     * Process the general information line about a logged packet.
     *
     * @param line The line of text from the file.
     * @param refDate Reference date.
     * @return Returns a wrapper with the packet data.
     */
    private static PacketInfo processGeneralInfoLine(String line, long refDate) throws PacketTracerException {

        /**
         * Parse fields
         */
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line, " ", false);

        // Local time
        String timeS = tokenizer.nextToken();
        int hour = Integer.parseInt(timeS.substring(0, 2)) + DIFF_UTC_TIME; // Adjust time to UTC
        int min = Integer.parseInt(timeS.substring(3, 5));
        int sec = Integer.parseInt(timeS.substring(6, 8));
        int mill = Integer.parseInt(timeS.substring(9, 12));

        // IP protocol
        tokenizer.nextToken();

        // Src address
        String srcAddressS = tokenizer.nextToken();
        String srcAddress;
        int srcPort;
        if (srcAddressS.indexOf(".") == -1) { // If the packet is under transport layer, there is no any port
            srcPort = 0;
            srcAddress = srcAddressS;
        } else {
            srcPort = Integer.parseInt(srcAddressS.substring(srcAddressS.indexOf(".") + 1));
            srcAddress = srcAddressS.substring(0, srcAddressS.indexOf("."));
        }

        // ">"
        tokenizer.nextToken();


        // Dest address
        String destAddressS = tokenizer.nextToken();
        String destAddress;
        int destPort;
        if (destAddressS.indexOf(".") == -1) {
            destPort = 0;
            destAddress = destAddressS.substring(0, destAddressS.length() - 1);
        } else {
            destPort = Integer.parseInt(destAddressS.substring(destAddressS.indexOf(".") + 1, destAddressS.length() - 1));
            destAddress = destAddressS.substring(0, destAddressS.indexOf("."));
        }


        // Protocol name and identifier (if possible)
        String protocolS = tokenizer.nextToken();
        int type;
        long id = 0;
        if (line.indexOf("win") >= 0) {
            type = PacketInfo.TYPE_TCP;
        } else if (protocolS.startsWith("UDP")) {
            type = PacketInfo.TYPE_UDP;
        } else if (protocolS.startsWith("ICMP")) {
            String icmpTypeS = tokenizer.nextToken();
            if (icmpTypeS.equals("echo")) {
                if (tokenizer.nextToken().startsWith("request")) {
                    type = PacketInfo.TYPE_ICMP_REQ;
                } else {
                    type = PacketInfo.TYPE_ICMP_REP;
                    id = PING_REP_ID_CORRECTOR; // Start a different numeration for response ICMP, to make the ID different
                }
                tokenizer.nextToken(); // "seq"
                String idS = tokenizer.nextToken();
                id += Integer.parseInt(idS.substring(0, idS.indexOf(",")));
            } else {
                return null;
            }
        } else {
            return null;
        }


        // "length"
        tokenizer.nextToken();

        // Packet length
        int length = 0;
        if (type != PacketInfo.TYPE_TCP) {
            length = Integer.parseInt(tokenizer.nextToken());
        }

        /**
         * Create the wrapper info object.
         */
        // Establish complete local time
        Calendar refTime = new GregorianCalendar();
        refTime.setTimeInMillis(refDate);
        Calendar localTime = (Calendar) refTime.clone();
        localTime.set(Calendar.HOUR_OF_DAY, hour);
        localTime.set(Calendar.MINUTE, min);
        localTime.set(Calendar.SECOND, sec);
        localTime.set(Calendar.MILLISECOND, mill);

        // Create IP src and dest address
        InetAddress srcAddr = null;
        InetAddress destAddr = null;
        try {
            srcAddr = InetAddress.getByName(srcAddress);
            destAddr = InetAddress.getByName(destAddress);
        } catch (UnknownHostException e) {
            throw new PacketTracerException("Error parsing IP addressese from dump file");
        }

//        System.out.println("src="+srcAddr+" dst="+destAddr+" sPort=" +destPort+ " dPort"+destAddr+" type="+type
//                +" len="+" id="+id);
        // Create wrapper object
        PacketInfo packetInfo = new PacketInfo(srcAddr, destAddr, srcPort, destPort, type, length, id, localTime.getTimeInMillis());
        packetInfo.addLocalTime(localTime.getTimeInMillis());

        return packetInfo;
    }

    /**
     * Process a log line with information about the ID of the packet.
     *
     * @param line The line from the file.
     * @return A string with the packet identifier.
     */
    private static String processIdDataLine(String line) {

        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        // Data address
        tokenizer.nextToken();

        // Create the string with the data. We need only the two first token. FFFF FFFF means millions of messages, so
        // the are not going to be repeated.
        String result = tokenizer.nextToken() + tokenizer.nextToken();

        return result;
    }

    /**
     * Process a log line (0x0060) with information about the source and source IPv6 addresses.
     *
     * @param line The line from the file.
     * @param A string with the source MAC address.
     */
    private static String processDestAddressLineNEMO1(String line) {

        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();

        // Get the source address
        String result = tokenizer.nextToken();
        return result;
    }

    /**
     * Process a log line (0x0060) with information about the source and source IPv6 addresses.
     *
     * @param line The line from the file.
     * @param A string with the source MAC address.
     */
    private static String processSrcAddressLineNEMO1(String line) {

        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();

        // Get the source address
        String result = tokenizer.nextToken();
        return result;
    }

    /**
     * Process a log line (0x0060) with information about the source and source IPv6 addresses.
     *
     * @param line The line from the file.
     * @param A string with the source MAC address.
     */
    private static String processSrcAddressLine1(String line) {

        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();

        // Get the source address
        String result = tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();

        return result;
    }

    /**
     * Process a log line (0x0070) with information about the source and source IPv6 addresses.
     *
     * @param line The line from the file.
     * @param A string with the source MAC address.
     */
    private static String processDestAddressLineNEMO2(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        /*       System.out.println("1" + tokenizer.nextToken());
        System.out.println("2" + tokenizer.nextToken());
        System.out.println("3" + tokenizer.nextToken());
        System.out.println("4" + tokenizer.nextToken());
         */
        tokenizer.nextToken();
        String result = ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();

        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();

        return result;
    }

    /**
     * Process a log line (0x0070) with information about the source and source IPv6 addresses.
     *
     * @param line The line from the file.
     * @param A string with the source MAC address.
     */
    private static String processSrcAddressLineNEMO2(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        /*       System.out.println("1" + tokenizer.nextToken());
        System.out.println("2" + tokenizer.nextToken());
        System.out.println("3" + tokenizer.nextToken());
        System.out.println("4" + tokenizer.nextToken());
         */
        tokenizer.nextToken();
        String result = ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();

        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();

        return result;
    }

    /**
     * Process a log line (0x0070) with information about the source and source IPv6 addresses.
     *
     * @param line The line from the file.
     * @param A string with the source MAC address.
     */
    private static String processSrcAddressLine2(String line) {

        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        /*       System.out.println("1" + tokenizer.nextToken());
        System.out.println("2" + tokenizer.nextToken());
        System.out.println("3" + tokenizer.nextToken());
        System.out.println("4" + tokenizer.nextToken());
         */
        tokenizer.nextToken();
        String result = ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();

        return result;
    }

    /**
     * Process a log line (0x0070) with information about the source and source IPv6 addresses.
     *
     * @param line The line from the file.
     * @param A string with the source MAC address.
     */
    private static String processDestAddressLine1(String line) {

        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();

        // Get the source address
        String result = tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();

        return result;
    }

    /**
     * Process a log line (0x0080) with information about the source and source IPv6 addresses.
     *
     * @param line The line from the file.
     * @param A string with the source MAC address.
     */
    private static String processDestAddressLine2(String line) {

        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        /*       System.out.println("1" + tokenizer.nextToken());
        System.out.println("2" + tokenizer.nextToken());
        System.out.println("3" + tokenizer.nextToken());
        System.out.println("4" + tokenizer.nextToken());
         */
        tokenizer.nextToken();
        String result = ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();
        result += ":";
        result += tokenizer.nextToken();

        return result;
    }

    /**
     * Process a log line with information about the source and destination MAC addresses.
     *
     * @param line The line from the file.
     * @param A string with the source MAC address.
     */
    private static String processSrcMACLine(String line) {

        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        // Data address
        tokenizer.nextToken();

        // Destination address
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();

        // Get the source address
        String result = tokenizer.nextToken();
        result += tokenizer.nextToken();
        result += tokenizer.nextToken();

        return result;
    }

    /**
     * Process a log line with information about the source and destination MAC addresses.
     *
     * @param line The line from the file.
     * @param A string with the destination MAC address.
     */
    private static String processDestMACLine(String line) {

        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);

        // Data address
        tokenizer.nextToken();

        // Get the destination address
        String result = tokenizer.nextToken();
        result += tokenizer.nextToken();
        result += tokenizer.nextToken();

        return result;
    }

    /**
     * Process destination port number and source port number
     * @param line The line from the file.
     */
    private static int processSrcPortLineAfterNEMO(String line) {
        int srcPort = 0;
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        String result = tokenizer.nextToken();
        srcPort = Integer.parseInt(result, 16);

        return srcPort;
    }

    /**
     * Process destination port number and source port number
     * @param line The line from the file.
     */
    private static int processSrcPortLine(String line) {
        int srcPort = 0;
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        srcPort = Integer.parseInt(tokenizer.nextToken(), 16);

        return srcPort;
    }

    /**
     * Process destination port number and source port number
     * @param line The line from the file.
     */
    private static int processDestPortLineAfterNEMO(String line) {
        int destPort = 0;
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        destPort = Integer.parseInt(tokenizer.nextToken(), 16);
        return destPort;
    }

    /**
     * Process destination port number and source port number
     * @param line The line from the file.
     */
    private static int processDestPortLine(String line) {
        int destPort = 0;
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        destPort = Integer.parseInt(tokenizer.nextToken(), 16);
        return destPort;
    }

    /**
     * Process type into 4 types (TYPE_UDP, TYPE_ICMP_REQ, TYPE_ICMP_REP, TYPE_TCP)
     * @param line The line from the file.
     * @return TYPE_UDP, TYPE_ICMP_REQ, TYPE_ICMP_REP, TYPE_TCP
     */
    private static int processTypeLineAfterNEMO(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();

        String result = tokenizer.nextToken();
        // 0x3a = 58 (ICMPv6, MLD)
        if (result.startsWith("3a")) {
            // put TYPE_ICMP_REQ temporally, because we need to see 0x0080 for distinguish request or reply
            return PacketInfo.TYPE_ICMP_REQ;
        } // 0x1 = 17 (UDP)
        else if (result.startsWith("11")) {
            return PacketInfo.TYPE_UDP;
        } // 0x6 = 6 (TCP)
        else if (result.startsWith("06")) {
            return PacketInfo.TYPE_TCP;
        }
        return 0;
    }

    /**
     * Process type into 4 types (TYPE_UDP, TYPE_ICMP_REQ, TYPE_ICMP_REP, TYPE_TCP)
     * @param line The line from the file.
     * @return TYPE_UDP, TYPE_ICMP_REQ, TYPE_ICMP_REP, TYPE_TCP
     */
    private static int processTypeLine(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();

        String result = tokenizer.nextToken();

        // 0x3a = 58 (ICMPv6, MLD)
        if (result.startsWith("3a")) {
            // put TYPE_ICMP_REQ temporally, because we need to see 0x0080 for distinguish request or reply
            return PacketInfo.TYPE_ICMP_REQ;
        } // 0x1 = 17 (UDP)
        else if (result.startsWith("11")) {
            return PacketInfo.TYPE_UDP;
        } // 0x6 = 6 (TCP)
        else if (result.startsWith("06")) {
            return PacketInfo.TYPE_TCP;
        } // 0x29 = 41 (IP header == NEMO)
        else if (result.startsWith("29")) {
            return PacketInfo.TYPE_NEMO_TUN;
        }// 0x3c = 60 (Destination option == BU)
        else if (result.startsWith("3c")) {
            return PacketInfo.TYPE_NEMO_BU;
        }// 0x2b = 43 (IPv6 routing Header == BA)
        else if (result.startsWith("2b")) {
            return PacketInfo.TYPE_NEMO_BA;
        }
        return 0;
    }

    /**
     * Process type into 2 types (TYPE_ICMP_REQ, TYPE_ICMP_REP)
     * @param line The line from the file.
     * @return TYPE_ICMP_REQ, TYPE_ICMP_REP
     */
    private static int processIcmpTypeLineAfterNEMO(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();

        String result = tokenizer.nextToken();

        // 0x80 = 128 (ICMPv6 echo request)
        if (result.startsWith("80")) {
            // put TYPE_ICMP_REQ temporally, because we need to see 0x0080 for distinguish request or reply
            return PacketInfo.TYPE_ICMP_REQ;
        } else {         // 0x81 = 129 (ICMPv6 echo reply)
            return PacketInfo.TYPE_ICMP_REP;
        }
    }

    /**
     * Process type into 2 types (TYPE_ICMP_REQ, TYPE_ICMP_REP)
     * @param line The line from the file.
     * @return TYPE_ICMP_REQ, TYPE_ICMP_REP
     */
    private static int processIcmpTypeLine(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        String result = tokenizer.nextToken();
        // 0x80 = 128 (ICMPv6 echo request)
        if (result.startsWith("80")) {
            // put TYPE_ICMP_REQ temporally, because we need to see 0x0080 for distinguish request or reply
            return PacketInfo.TYPE_ICMP_REQ;
        } else {         // 0x81 = 129 (ICMPv6 echo reply)
            return PacketInfo.TYPE_ICMP_REP;
        }
    }

    /**
     * Process type into 2 types (TYPE_ICMP_REQ, TYPE_ICMP_REP)
     * @param line The line from the file.
     * @return TYPE_ICMP_REQ, TYPE_ICMP_REP
     */
    private static int processIcmpSequenceLineAfterNEMO(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        String result = tokenizer.nextToken();
        return Integer.decode("0x" + result);
    }

    /**
     * Process type into 2 types (TYPE_ICMP_REQ, TYPE_ICMP_REP)
     * @param line The line from the file.
     * @return TYPE_ICMP_REQ, TYPE_ICMP_REP
     */
    private static int processUDPSequenceLineAfterNEMO(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        String result = tokenizer.nextToken();
        return Integer.decode("0x" + result);
    }

    /**
     * Process type into 2 types (TYPE_ICMP_REQ, TYPE_ICMP_REP)
     * @param line The line from the file.
     * @return TYPE_ICMP_REQ, TYPE_ICMP_REP
     */
    private static int processIcmpSequenceLine(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        String result = tokenizer.nextToken();
        return Integer.decode("0x" + result);
    }

    /**
     * Process BU Sequence Number
     * @param line The line from the file.
     * @return Sequence number
     */
    private static int processBUSequence(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        String result = tokenizer.nextToken();
        return Integer.decode("0x" + result);
    }

    /**
     * Process BA Sequence Number
     * @param line The line from the file.
     * @return Sequence number
     */
    private static int processBASequence(String line) {
        // Separate main fields
        StringTokenizer tokenizer = new StringTokenizer(line.substring(1), " ", false);
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        tokenizer.nextToken();
        String result = tokenizer.nextToken();
        return Integer.decode("0x" + result);
    }

    /**
     * Trace a packet along the logs.
     *
     * @param sentPackets Set of packets sent from the source MR.
     * @param packetHashtables Logged packets in each MR, sorted in a hashtable.
     * @param mrIds Identifiers for each MR, in the same order as dumpFiles. First one is source MR.
     * @param mrMacs MAC addresses for each MR, in the same order as dumpFiles. First one is source MR.
     * @param packetType The type of packet to search for.
     * @return Trace informati�n for each packet send from the first MR.
     */
    private static Vector<PacketTrace> tracePackets(PacketInfo[] sentPackets, Hashtable[] packetHashtables, String[] mrIds, String[] mrMacs, int packetType, int destMRNumFromLast) {

        Vector<PacketTrace> packetTraces = new Vector<PacketTrace>();
//        for (int i = 0; i < mrIds.length; i++) {
//            System.out.println("mrIds [" + i + "]=" + mrIds[i].toString() + " mrMacs [" + i + "]=" + mrMacs[i].toString());
//        }

        System.out.print("00%");
        // Search for each packet sent in the rest of logs
        for (int i = 0; i
                < sentPackets.length; i++) {
            // Update % completed each 1%
            if (sentPackets.length != 0 || (i % (sentPackets.length / 100)) == 0) {
                int perc = (i * 100) / sentPackets.length;
                if (perc < 10) {
                    System.out.print("\b\b");
                } else {
                    System.out.print("\b\b\b");
                }
                System.out.print(perc + "%");
            }
            // Skip all packets which do not fit the packet type required
            
            if (packetType == IPERF_PACKET) {
                if (sentPackets[i].getType() != sentPackets[i].TYPE_UDP
                        || sentPackets[i].getLength() != IPERF_PACKET_SIZE) //  C2CNET header makes packets bigger
                {
                    continue;
                }
            } else if (packetType == PING_REQ_PACKETS && sentPackets[i].getType() != PacketInfo.TYPE_ICMP_REQ) {
                continue;
            } else if (packetType == PING_REP_PACKETS && sentPackets[i].getType() != PacketInfo.TYPE_ICMP_REP) {
                continue;
            } else if (packetType == BU_PACKETS && sentPackets[i].getType() != PacketInfo.TYPE_NEMO_BU) {
                continue;
            } else if (packetType == BA_PACKETS && sentPackets[i].getType() != PacketInfo.TYPE_NEMO_BA) {
                continue;
            }

            // Create a trace for the packet
            PacketTrace packetTrace = new PacketTrace(sentPackets[i]);
            // Search the route followed by the packet from the source MR
            PacketInfo packetInfo = null;
            int tableIndex = 0;

            for (packetInfo = (PacketInfo) packetHashtables[tableIndex].get(sentPackets[i].getId());
                    packetInfo != null;
                    packetInfo = (PacketInfo) packetHashtables[tableIndex].get(sentPackets[i].getId())) {

                // Get current MR
                String currentMR = mrIds[tableIndex];

                // Get source MR
                Vector<String> srcAddresses = packetInfo.getSrcMACAddresses();
                srcAddresses.remove(0);
                packetInfo.setSrcMACAddresses(srcAddresses);

                // Get next MR
                Vector<String> destAddresses = packetInfo.getDestMACAddresses();
                String nextMR = macToMr(destAddresses.remove(0), mrIds, mrMacs);
                packetInfo.setDestMACAddresses(destAddresses);


                // Get the log time
                Vector<Long> localTimes = packetInfo.getLocalTimes();
                long localTime = localTimes.remove(0);
                packetInfo.setLocalTimes(localTimes);
                // Remove the packet entry if the packet has not arrived more times
                if (srcAddresses.size() == 0) {
                    packetHashtables[tableIndex].remove(sentPackets[i].getId());
                }
                // Add the new link
                // Only one Destination case
//                if (!currentMR.equals(nextMR) || tableIndex == packetHashtables.length - 1) {
                // multiple destination case (if there are link, add it)
                if (!currentMR.equals(nextMR)
                        || (tableIndex >= packetHashtables.length - destMRNumFromLast)
                        && (tableIndex < packetHashtables.length)) {
//                if (!currentMR.equals(nextMR) || tableIndex !=0) {
//                if (!currentMR.equals(nextMR) || tableIndex == packetHashtables.length - 1 || tableIndex == packetHashtables.length - 2) {

                    packetTrace.addTrace(currentMR, localTime, nextMR);
                } // Find the next hash table were search for the packet
                tableIndex = indexOfString(nextMR, mrIds);
            }

            packetTraces.add(packetTrace);
        }
        System.out.print("\b\b\b");
        return packetTraces;
    }

    private static String macToMr(String mac, String[] mrIds, String[] mrMacs) {

        for (int i = 0; i
                < mrMacs.length; i++) {
            if (mrMacs[i].equals(mac)) {
                return mrIds[i];
            }
        }
        return null;
    }

    private static int indexOfString(String string, String[] strings) {
        for (int i = 0; i < strings.length; i++) {
            if (strings[i].equals(string)) {
                return i;
            }
        }
        return -1;
    }
}
