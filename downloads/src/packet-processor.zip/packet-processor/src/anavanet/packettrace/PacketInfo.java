/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */


package anavanet.packettrace;

import java.net.InetAddress;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Vector;
import java.net.UnknownHostException;

/**
 * Wrapper for information about each packet logged in a MR.
 *
 * @author Jos� Santa Lozano
 * @author Manabu Tsukada
 */
public class PacketInfo {

    // Source address
    private InetAddress srcAddress;
    // Destination address
    private InetAddress destAddress;
    // Source port
    private int srcPort;
    // Destination port
    private int destPort;
    // Type of packet
    private int type;
    // Length
    private int length;
    // Unique packet identifier
    private long id;
    // Local time of the first log for the packet
    private long localTime;
    // Timestamps when the packet were logged
    private Vector<Long> localTimes;
    // Source MAC address
    private Vector<String> srcMACAddresses;
    // Destination MAC address
    private Vector<String> destMACAddresses;
    /**
     * UDP packet type.
     */
    public static final int TYPE_UDP = 0;
    /**
     * ICMP Request packet type.
     */
    public static final int TYPE_ICMP_REQ = 1;
    /**
     * ICMP Reply packet type.
     */
    public static final int TYPE_ICMP_REP = 2;
    /**
     * TCP packet type.
     */
    public static final int TYPE_TCP = 3;
    /**
     * NEMO packet type.
     */
    public static final int TYPE_NEMO_TUN = 4;
    /**
     * BU packet type.
     */
    public static final int TYPE_NEMO_BU = 5;
    /**
     * BU packet type.
     */
    public static final int TYPE_NEMO_BA = 6;

    /**
     * Creates a new wrapper for a packet logged.
     */
    public PacketInfo(InetAddress srcAddress, InetAddress destAddress, int srcPort, int destPort, int type, int length, long id, long localTime) {

        this.srcAddress = srcAddress;
        this.destAddress = destAddress;
        this.srcPort = srcPort;
        this.destPort = destPort;
        this.type = type;
        this.length = length;
        this.localTimes = new Vector<Long>();
        this.id = id;
        this.srcMACAddresses = new Vector<String>();
        this.destMACAddresses = new Vector<String>();
        this.localTime = localTime;
    }

    /**
     * Gets the source address of the packet.
     *
     * @return The source address.
     */
    public InetAddress getSrcAddress() {
        return srcAddress;
    }

    /**
     * Gets the destination address of the packet.
     *
     * @return The destination address.
     */
    public InetAddress getDestAddress() {
        return destAddress;
    }

    /**
     * Gets the source address of the packet.
     *
     * @return The source address.
     */
    public InetAddress addSrcAddress() {
        return srcAddress;
    }

    /**
     * Adds a new destination IPv6 address
     */
    public void setDestAddress(String destIpv6Address) throws PacketTracerException {
        try {
            this.destAddress = InetAddress.getByName(destIpv6Address);
        } catch (UnknownHostException e) {
            throw new PacketTracerException("Error setting DST IP addressese from dump file");
        }
    }

    /**
     * Adds a new src IPv6 address
     */
    public void setSrcAddress(String srcIpv6Address) throws PacketTracerException {
        try {
            this.srcAddress = InetAddress.getByName(srcIpv6Address);
        } catch (UnknownHostException e) {
            throw new PacketTracerException("Error setting SRC IP addressese from dump file");
        }
    }

    /**
     * Sets the source port for the packet.
     *
     * @param Source port
     */
    public void setSrcPort(int srcPort) {

        this.srcPort = srcPort;
    }

    /**
     * Sets the destination port for the packet.
     *
     * @param Source port
     */
    public void setDestPort(int destPort) {

        this.destPort = destPort;
    }

    /**
     * Gets the port used at the source host.
     *
     * @return The port number.
     */
    public int getSrcPort() {
        return srcPort;
    }

    /**
     * Gets the port used at the destination host.
     *
     * @return The port number.
     */
    public int getDestPort() {
        return destPort;
    }

    /**
     * Gets the type of the packet captured.
     *
     * @return The packet type, according to the types defined in as static fields in this class.
     */
    public int getType() {
        return type;
    }

    /**
     * Gets the total length of the packet.
     *
     * @return The length in bytes.
     */
    public int getLength() {
        return length;
    }

    /**
     * Gets the unique identifier for the packet, fixing source and destination addresses and ports, and protocol used.
     *
     * @return The packet identifier, or -1 if the identifier has not been set.
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the Type for the packet.
     *
     * @param The packet identifier.
     */
    public void setType(int type) {

        this.type = type;
    }

    /**
     * Sets the unique identifier for the packet.
     *
     * @param The packet identifier.
     */
    public void setId(long id) {

        this.id = id;
    }

    /**
     * Get the first local time when the packet were logged.
     *
     * @return The local time in Java milliseconds.
     */
    public long getLocalTime() {

        return localTime;
    }

    /**
     * Gets the time where the packet were logged in the MR.
     *
     * @return The local time of the MR in Java milliseconds.
     */
    public Vector<Long> getLocalTimes() {

        return localTimes;
    }

    /**
     * Sets the local times when the packet were logged.
     *
     * @param The local times.
     */
    public void setLocalTimes(Vector<Long> localTimes) {

        this.localTimes = localTimes;
    }

    /**
     * Gets the source MAC addresses for each time the packet has been received.
     *
     * @return The MAC address strings.
     */
    public Vector<String> getSrcMACAddresses() {

        return srcMACAddresses;
    }

    /**
     * Sets the source MAC addresses for each time the packet has been received.
     *
     * @param srcMACAddresses The new source MAC addresses.
     */
    public void setSrcMACAddresses(Vector<String> srcMACAddresses) {

        this.srcMACAddresses = srcMACAddresses;
    }

    /**
     * Gets the destination MAC addreses for each time the packet has been received.
     *
     * @return The MAC address strings.
     */
    public Vector<String> getDestMACAddresses() {

        return destMACAddresses;
    }

    /**
     * Sets the destination MAC addresses for each time the apcket has been received.
     *
     * @param destMACAddresses The new destination MAC addresses.
     */
    public void setDestMACAddresses(Vector<String> destMACAddresses) {

        this.destMACAddresses = destMACAddresses;
    }

    /**
     * Adds a new log time for the the packet.
     *
     * @param The log time in Java milliseconds.
     */
    public void addLocalTime(long localTime) {

        localTimes.add(localTime);
    }

    /**
     * Adds a new source MAC addresses for for a logged packet.
     *
     * @return The MAC address string.
     */
    public void addSrcMACAddress(String srcMACAddress) {

        srcMACAddresses.add(srcMACAddress);
    }

    /**
     * Adds a new destination MAC addresses for for a logged packet.
     *
     * @return The MAC address string.
     */
    public void addDestMACAddress(String destMACAddress) {

        destMACAddresses.add(destMACAddress);
    }

    public boolean equals(Object o) {

        if (!(o instanceof PacketInfo)) {
            return false;
        }

        PacketInfo packetInfo = (PacketInfo) o;

        if (packetInfo.getType() == type
                && packetInfo.getLength() == length
                && packetInfo.getSrcAddress().equals(srcAddress)
                && packetInfo.getDestAddress().equals(destAddress)
                && packetInfo.getSrcPort() == srcPort
                && packetInfo.getDestPort() == destPort
                && packetInfo.getId() == id) {
            return true;
        }

        return false;
    }

    public String toString() {

        String result = "";

        Calendar calendar = new GregorianCalendar();
        calendar.setTimeInMillis(localTime);
        result += calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND) + " ";
        result += srcMACAddresses + " ";
        result += destMACAddresses + " ";
        result += srcAddress + " ";
        result += srcPort + " ";
        result += destAddress + " ";
        result += destPort + " ";
        result += type + " ";
        result += length + " ";
        result += id;
        result += "\n";

        return result;
    }
}
