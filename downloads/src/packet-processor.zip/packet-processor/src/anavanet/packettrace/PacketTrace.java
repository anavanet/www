/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */


package anavanet.packettrace;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Vector;

/**
 * Wrapper for information about packet emmited and the trace followed among MRs.
 *
 * @author Jos� Santa Lozano
 * @author Manabu Tsukada
 */
public class PacketTrace {

    // Packet information
    private PacketInfo packetInfo;
    // Mobile routers where the packet has been found
    private Vector<String> mobileRouters;
    // Time stamp of each mobile router for the packet
    private Vector<Long> localTimes;
    // Next mobile router where the packet will be sent
    private Vector<String> nextHops;

    /**
     * Creates a new trace for a packet.
     */
    public PacketTrace(PacketInfo packetInfo, String[] mobileRouters, long[] localTimes, String[] nextHops) {

        this.packetInfo = packetInfo;
        this.mobileRouters = new Vector<String>();
        for (int i = 0; i < mobileRouters.length; i++) {
            this.mobileRouters.add(mobileRouters[i]);
        }
        this.localTimes = new Vector<Long>();
        for (int i = 0; i < localTimes.length; i++) {
            this.localTimes.add(new Long(localTimes[i]));
        }
        this.nextHops = new Vector<String>();
        for (int i = 0; i < nextHops.length; i++) {
            this.nextHops.add(nextHops[i]);
        }
    }

    /**
     * Creates a new trace for a packet with only the packet information.
     */
    public PacketTrace(PacketInfo packetInfo) {

        this.packetInfo = packetInfo;
        this.mobileRouters = new Vector<String>();
        this.localTimes = new Vector<Long>();
        this.nextHops = new Vector<String>();
    }

    /**
     * Adds a new trace for the packet.
     *
     * @param mobileRouter The name of the MR where the packet were logged.
     * @param localTime The local time of the MR when the packet were logged, in Java milliseconds.
     */
    public void addTrace(String mobileRouter, long localTime, String nextHop) {

        mobileRouters.add(mobileRouter);
        localTimes.add(localTime);
        nextHops.add(nextHop);
    }

    /**
     * Get the packet information.
     *
     * @return The packet information wrapper.
     */
    public PacketInfo getPacketInfo() {

        return packetInfo;
    }

    /**
     * Get the mobile routers identifiers where the packet has been logged, in the same order the were
     * provided.
     *
     * @return The mobile routers identifiers.
     */
    public String[] getMobileRouters() {

        return mobileRouters.toArray(new String[0]);
    }

    /**
     * Set the mobile reouters identifiers where the packet has been logged.
     *
     * @param The mobile routers identifers.
     */
    public void setMobileRouters(String[] mrs) {

        this.mobileRouters = new Vector<String>(mrs.length);
        for (int i = 0; i < mrs.length; i++) {
            mobileRouters.add(mrs[i]);
        }
    }

    /**
     * Get the local time of the computers when the packet were received.
     *
     * @return The time in Java milliseconds.
     */
    public long[] getLocalTimes() {
        long[] longs = new long[localTimes.size()];
        for (int i = 0; i < localTimes.size(); i++) {
            longs[i] = localTimes.get(i).longValue();
        }

        return longs;
    }

    /**
     * Set the local time of the MR when the packet were received.
     *
     * @param The local times in Java milliseconds.
     */
    public void setLocalTimes(long[] localTimes) {

        this.localTimes = new Vector<Long>(localTimes.length);
        for (int i = 0; i < localTimes.length; i++) {
            this.localTimes.add(localTimes[i]);
        }
    }

    /**
     * Get the next mobiles routers where the packet is going to be lauched in each hop.
     *
     * @return The identifiers of the next mobile routers.
     */
    public String[] getNextHops() {
        return nextHops.toArray(new String[0]);
    }

    /**
     * Set the next mobile routers where the packet is going to be launched in each hop.
     *
     * @param The identifiers of the next mobile routers.
     */
    public void setNextHops(String[] nextHops) {

        this.nextHops = new Vector<String>(nextHops.length);
        for (int i = 0; i < nextHops.length; i++) {
            this.nextHops.add(nextHops[i]);
        }
    }
    public String toString() {

        String result = "";

        Calendar calendar = new GregorianCalendar();
        calendar.setTimeInMillis(packetInfo.getLocalTime());

        result += calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE) + ":" + calendar.get(Calendar.SECOND) + "." + calendar.get(Calendar.MILLISECOND) + " ";
        result += mobileRouters.size();
        for (int i = 0; i < mobileRouters.size(); i++) {
            result += " " + mobileRouters.get(i) + "(" + nextHops.get(i) + ")";
        }
        if (packetInfo.getType() == packetInfo.TYPE_ICMP_REQ) {
            if (mobileRouters.size() >= 4 && mobileRouters.get(0).equals(mobileRouters.get(mobileRouters.size() - 1))) {
                result += " " + (localTimes.get(localTimes.size() - 1) - packetInfo.getLocalTime());
            }
        }

        return result;
    }

}
