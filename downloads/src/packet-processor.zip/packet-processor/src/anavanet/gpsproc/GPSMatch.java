/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet.gpsproc;

import java.util.GregorianCalendar;
import java.util.Vector;

/**
 * This class maintains a momentaneous match of the position of two vehicles (MR) in a concrete UTC-GPS time.
 *
 * @author Jos� Santa Lozano
 */
public class GPSMatch {
    
    // UTC time of both GPS fixes
    private long fixTime;
    
    // Name of the MR
    private Vector<String> mrIds;
    
    // Estimated local times of each MR
    private Vector<Long> localTimes;
        
    // Latitude of MR positions
    private Vector<Double> latitudes;
    
    // Longitude of MR positions
    private Vector<Double> longitudes;
    
    // Speeds of vehcles
    private Vector<Double> speeds;
    
    // Distances betwen each pair of MR
    private Vector<Double> distances;
    
    /**
     * Creates a new GPS match object between vehicles (MR).
     *
     * @param fixTime The UTC-GPS time of the fix.
     * @param mrId Identifier of the MR.
     * @param localTime The estimated local time of the source MR for the fix.
     * @param latitude The latitude of the source MR position.
     * @param longitude The longitude of the source MR position.
     * @param speed Current speed of the vehicle.
     */
    public GPSMatch(long fixTime, String mrId, long localTime, double latitude, double longitude, double speed) {
        
        this.fixTime = fixTime;
        
        localTimes = new Vector<Long>();
        mrIds = new Vector<String>();
        latitudes = new Vector<Double>();
        longitudes = new Vector<Double>();
        speeds = new Vector<Double>();
        distances = new Vector<Double>();
        
        localTimes.add(new Long(localTime));
        mrIds.add(mrId);
        latitudes.add(new Double(latitude));
        longitudes.add(new Double(longitude));
        speeds.add(new Double(speed));
        distances.add(new Double(0));
    }

    /**
     * Create a new GPS match with all fields.
     *
     */
    public GPSMatch (long fixTime, Vector<String> mrIds, Vector<Long> localTimes, Vector<Double> latitudes,
            Vector<Double> longitudes, Vector<Double> speeds, Vector<Double> distances) {
        
        this.fixTime = fixTime;
        this.mrIds = mrIds;
        this.localTimes = localTimes;
        this.latitudes = latitudes;
        this.longitudes = longitudes;
        this.speeds = speeds;
        this.distances = distances;
    }
    
    /**
     * Forwards the time of the GPS match by the value given.
     *
     * @param The time to forward fix and local times.
     */
    public void forwardTime(long time) {
        
        fixTime += time;
        for (int i=0; i<localTimes.size(); i++)
            localTimes.set(i, localTimes.get(i)+time);
    }
    
    /**
     * Modify the position by adding an offset.
     *
     * @param latitudeOffset The offset of the latitudes for each vehicle in degrees.
     * @praam longitudeOffset The offset of the longitudes for each vehicle in degrees.
     */
    public void movePositions(double[] latitudeOffset, double[] longitudeOffset) {
        
        for (int i=0; i<latitudes.size(); i++) {
            
            latitudes.set(i, latitudes.get(i)+latitudeOffset[i]);
            longitudes.set(i, longitudes.get(i)+longitudeOffset[i]);
        }
    }
    
    /**
     * Adds a new GPS match from a MR.
     *
     * @param localTime The local time of the fix in the MR.
     * @param mrId Identifier of the MR.
     * @param latitude The latitude of the MR position.
     * @param longitude The longitude of the MR position.
     * @param speed Current speed of the vehicle.
     */
    public void addGPSMatch(long localTime, String mrId, double latitude, double longitude, double speed) {
        
        localTimes.add(new Long(localTime));
        mrIds.add(mrId);
        latitudes.add(new Double(latitude));
        longitudes.add(new Double(longitude));
        speeds.add(new Double(speed));
        
        // Calculate the distance between current MR and past notified
        double distance = 0;
        if (localTimes.size() > 1)
            distance = llDistance(latitudes.get(latitudes.size()-2).doubleValue(), longitudes.get(longitudes.size()-2).doubleValue(),
                    latitude, longitude);
        
        distances.add(new Double(distance));
    }
    
     /**
     * Get the UTC time of the momentaneous distance.
     *
     * @return The time in Java milliseconds.
     */
    public long getFixTime() {
        return fixTime;
    }
    
    /**
     * Get the estimated local time of each MR when the momentaneous distance
     * has been calculated.
     *
     * @return The time in Java milliseconds.
     */
    public long[] getLocalTimes() {
        long[] longLocalTimes = new long[localTimes.size()];
        for (int i=0; i<localTimes.size(); i++)
            longLocalTimes[i] = localTimes.get(i).longValue();
        
        return longLocalTimes;
    }
    
    /**
     * Get the MR identifiers of the GPS match.
     *
     * @return The MR identifiers.
     */
    public String[] getMrIds() {
        
        return mrIds.toArray(new String[0]);
    }
    
    /**
     * Get the latitude of the MR positions.
     *
     * @return The latitude in degrees.
     */
    public double[] getLatitudes() {
        double[] longLatitudes = new double[latitudes.size()];
        for (int i=0; i<latitudes.size(); i++)
            longLatitudes[i] = latitudes.get(i).doubleValue();
        
        return longLatitudes;
    }
    
    /**
     * Get the longitude of the MR positions.
     *
     * @return The longitude in degrees.
     */
    public double[] getLongitudes() {
        double[] longLongitudes = new double[longitudes.size()];
        for (int i=0; i<longitudes.size(); i++)
            longLongitudes[i] = longitudes.get(i).doubleValue();
        
        return longLongitudes;
    }
    
    /**
     * Get the speed of the vehicles in the momentaneous match.
     *
     * @return The speed in Km/h.
     */
    public double[] getSpeeds() {
        double[] longSpeeds = new double[speeds.size()];
        for (int i=0; i<speeds.size(); i++)
            longSpeeds[i] = speeds.get(i).doubleValue();
        
        return longSpeeds;
    }
    
    /**
     * Get the momentaneous distance between each pair of vehicles.
     *
     * @return The distances in meters.
     */
    public double[] getDistances() {
        double[] longDistances = new double[distances.size()];
        for (int i=0; i<distances.size(); i++)
            longDistances[i] = distances.get(i).doubleValue();
        
        return longDistances;
    }
    
    /**
     * Check if the match contains the desired MR.
     *
     * @param mrs Number of MRs where it is desired to find the GPSFix.
     * @return True if the GPSFix has been matched with the desired MR, false otherwise.
     */
    public boolean checkMatch(int mrs) {
        
        if (localTimes.size() == mrs)
            return true;
        
        return false;
    }
    
    public String toString() {
        
        String result = "";
        
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTimeInMillis(fixTime);
        result += calendar.get(calendar.DAY_OF_MONTH) + "/" + (calendar.get(calendar.MONTH)+1) + "/" + calendar.get(calendar.YEAR);
        result += " " + calendar.get(calendar.HOUR_OF_DAY) + ":" + calendar.get(calendar.MINUTE) + ":" + calendar.get(calendar.SECOND);
        for (int i=0; i<localTimes.size(); i++) {
            result += " " + mrIds.get(i);
            calendar.setTimeInMillis(localTimes.get(i));
            result += " " + calendar.get(calendar.DAY_OF_MONTH) + "/" + (calendar.get(calendar.MONTH)+1) + "/" + calendar.get(calendar.YEAR);
            result += " " + calendar.get(calendar.HOUR_OF_DAY) + ":" + calendar.get(calendar.MINUTE) + ":" + calendar.get(calendar.SECOND);
            result += " " + speeds.get(i).doubleValue();
            result += " " + distances.get(i).doubleValue();
        }

        return result;
    }
    
    /**
     * Calculates a distance between two geographical points in latitude/longitude.
     *
     * @param latPoint1 Latitude of first point.
     * @param lonPoint1 Longitude of first point.
     * @param latPoint2 Latitude of second point.
     * @param lonPoint2 Longitude of second point.
     */
    private static double llDistance(double latPoint1, double lonPoint1, double latPoint2, double lonPoint2) {
        
        // Distance = 0
        if (latPoint1 == latPoint2 && lonPoint1 == lonPoint2)
            return 0;
        
        // Pass values from degreees to radians
        latPoint1 = Math.toRadians(latPoint1);
        lonPoint1 = Math.toRadians(lonPoint1);
        latPoint2 = Math.toRadians(latPoint2);
        lonPoint2 = Math.toRadians(lonPoint2);
        
        double calculation = Math.sin(latPoint1)*Math.sin(latPoint2)+Math.cos(latPoint1)*Math.cos(latPoint2)*Math.cos(lonPoint1-lonPoint2);
        
        double distance = 0;
        if (calculation > 1)
            distance = 6378700 * Math.acos(1);
        else
            distance = 6378700 * Math.acos(calculation);
        
        return distance;
    }
    
    protected Object clone() {
        
        return new GPSMatch(fixTime, (Vector<String>)mrIds.clone(), (Vector<Long>)localTimes.clone(),
                (Vector<Double>)latitudes.clone(), (Vector<Double>)longitudes.clone(), (Vector<Double>)speeds.clone(),
                (Vector<Double>)distances.clone());
    }
}
