/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet.gpsproc;

/**
 * Error occurred while processing GPS logs.
 *
 * @author Jos� Santa Lozano
 */
public class GPSProcessorException extends java.lang.Exception {
    
    /**
     * Creates a new instance of <code>GPSProcessorException</code> without detail message.
     */
    public GPSProcessorException() {
    }
    
    
    /**
     * Constructs an instance of <code>GPSProcessorException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public GPSProcessorException(String msg) {
        super(msg);
    }
}
