/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet.gpsproc;

import java.io.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;
import java.util.Vector;

/**
 * Class with methods for filtering GPS logs.
 *
 * @author Jos� Santa Lozano
 */
public class GPSProcessor {
    
    // Local time identifier for log files
    private static String TIME_ID="TIME";
    
    // NMEA RMC message identifier
    private static String RMC_ID="$GPRMC";
    
    /**
     * Process a GPS log file from VANET tests. Initial local time records are used to match the
     * local time of the first GPS fix. Local time of next ones are calculated in base of the first
     * match, using the UTC time of the GPS fix.
     *
     * @param is File object of the GPS log file.
     * @return A set of GPSPosition objects for each GPS fix.
     */
    public static GPSFix[] processGPSLog(File file) throws GPSProcessorException {
        
        try {
            
            // Access the file
            BufferedReader in = new BufferedReader(new FileReader(file));
            
            // Process log lines
            String line;
            GregorianCalendar localTime = new GregorianCalendar();
            localTime.setTimeInMillis(0);
            GPSFix firstGpsFix = null;
            Vector<GPSFix> gpsFixes = new Vector<GPSFix>();
            while ((line = in.readLine()) != null) {
                
                // Pass blank lines
                if (line.length() < 6)
                    continue;
                
                // Process local time messages until the first GPS fix is created
                if (line.startsWith(TIME_ID) && firstGpsFix == null)
                    processTimeLine(line, localTime);
                
                // Process NMEA RMC when the local time has been read
                else if (line.startsWith(RMC_ID) && localTime.getTimeInMillis() != 0) {
                    
                    // Create the new fix and update local time
                    GPSFix gpsFix = processRMCLine(line, localTime, firstGpsFix);
                    
                    // Save the first GPS fix to maintain a local time reference with UTC time
                    if (firstGpsFix==null)
                        firstGpsFix=gpsFix;
                    
                    // Save the gpsFix if it's OK
                    if (gpsFix != null)
                        gpsFixes.add(gpsFix);
                }
            }
            
            // Check if the local time has been synchronized with UTC time from GPS
            if (firstGpsFix == null)
                throw new GPSProcessorException("Local time not synchronized with GPS UTC time in log");
            
            return gpsFixes.toArray(new GPSFix[0]);
            
        } catch (IOException e) {
            
            throw new GPSProcessorException("I/O error: " + e.getMessage());
        }
    }
    
    /**
     * Computes the momentaneous distances between a pair of vehicles.
     *
     * @param gpsFixes1 GPS positions for the first vehicle.
     * @param gpsFixes2 GPS positions for the second vehicle.
     * @return The momentaneous distances calculated between the two vehicles.
     */
    public static GPSMatch[] calculateMomentaneousGPSMatches(Vector<GPSFix[]> gpsFixes, Vector<String> mrIds) {
        
        Vector<GPSMatch> gpsMatches = new Vector<GPSMatch>();
        
        // Match each fix for the first vehicle with a fix of the second one, using the UTC-GPS time as index
        GPSFix[] srcGPSFixes = gpsFixes.get(0);
        int[] indexes = new int[gpsFixes.size()-1];
        for (GPSFix srcGpsFix : srcGPSFixes) {
            
            // Check fixes from the rest of MR
            GPSMatch gpsMatch = new GPSMatch(srcGpsFix.getFixTime(), mrIds.get(0), srcGpsFix.getLocalTime(), srcGpsFix.getLatitude(), srcGpsFix.getLongitude(), srcGpsFix.getSpeed());
            for (int i=1; i<gpsFixes.size(); i++) {
                
                
                // Analyse a new log
                GPSFix[] currentGPSFixes = gpsFixes.get(i);
                indexes[i-1] = 0;
                
                // Move the list of fixes until align with the source one
                GPSFix gpsFix = null;
                for (; indexes[i-1]<currentGPSFixes.length; indexes[i-1]++) {
                    gpsFix = currentGPSFixes[indexes[i-1]];
                    if (gpsFix.getFixTime()>=srcGpsFix.getFixTime())
                        break;
                }
                
                // Check for the end of the current log
                if (gpsFix == null)
                    break;
                
                // Search for a match
                else if (gpsFix.getFixTime() == srcGpsFix.getFixTime()) {
                    
                    // Save the new distance
                    gpsMatch.addGPSMatch(gpsFix.getLocalTime(), mrIds.get(i), gpsFix.getLatitude(), gpsFix.getLongitude(), gpsFix.getSpeed());
                }
            }
            
            // Save the new match if it is successful
            if (gpsMatch.checkMatch(gpsFixes.size()))
                gpsMatches.add(gpsMatch);
        }
        
        return gpsMatches.toArray(new GPSMatch[0]);
    }
    
    /**
     * Check if the set of fixes is continous.
     *
     * @param gpsFixes Set of matches.
     * @return The set of discontiuties in pairs.
     */
    public static GPSFix[] checkFixContinuity(GPSFix[] gpsFixes) {
        
        Vector<GPSFix> discontinuities = new Vector<GPSFix>();
        
        if (gpsFixes.length < 1)
            return new GPSFix[0];
        
        for (int i=1; i<gpsFixes.length; i++) {
            
            if (gpsFixes[i].getFixTime() != (gpsFixes[i-1].getFixTime()+1000)) {
                discontinuities.add(gpsFixes[i-1]);
                discontinuities.add(gpsFixes[i]);
            }
        }
        
        return discontinuities.toArray(new GPSFix[0]);
    }
    
    /**
     * Fill GPS fix discontinuities, and fill holes with an estimation of the position.
     *
     * @param gpsFixes Set of matches.
     * @return The filled GPS fix set.
     */
    public static GPSFix[] fillFixDiscontinuity(GPSFix[] gpsFixes) {
        
        Vector<GPSFix> result = new Vector<GPSFix>();
        
        if (gpsFixes.length < 1)
            return gpsFixes;
        
        result.add(gpsFixes[0]);
        
        for (int i=1; i<gpsFixes.length; i++) {
            
            if (gpsFixes[i].getFixTime() == gpsFixes[i-1].getFixTime())
                continue;
            
            else if (gpsFixes[i].getFixTime() != (gpsFixes[i-1].getFixTime()+1000)) {
                
                // Calculate differences of the positions between non consecutive matches
                double latDiff = (gpsFixes[i].getLatitude() - gpsFixes[i-1].getLatitude()) / ((gpsFixes[i].getFixTime() - gpsFixes[i-1].getFixTime())/1000);
                double lonDiff = (gpsFixes[i].getLongitude() - gpsFixes[i-1].getLongitude()) / ((gpsFixes[i].getFixTime() - gpsFixes[i-1].getFixTime())/1000);
                
                // Create the new filling matches
                int k = 1;
                for (long j=gpsFixes[i-1].getFixTime()+1000; j<gpsFixes[i].getFixTime(); j+=1000, k++) {
                    
                    // Clone the previous match
                    GPSFix gpsFix = (GPSFix)gpsFixes[i-1].clone();
                    
                    // Modify the fixtimes
                    gpsFix.forwardTime(1000*k);
                    
                    // Extrapolate the position
                    gpsFix.movePosition(latDiff*k, lonDiff*k);
                    
                    // Add the new match
                    result.add(gpsFix);
                }
            }
            
            result.add(gpsFixes[i]);
        }
        
        return result.toArray(new GPSFix[0]);
    }
    
    /**
     * Process a TIME line from the log file.
     *
     * @param line Time line read from the log file.
     * @param calendar Calendar object to update according to the new time.
     */
    private static void processTimeLine(String line, Calendar calendar) {
        
        // Separate fields
        StringTokenizer tokenizer = new StringTokenizer(line, ":", false);
        
        // Get fields
        tokenizer.nextToken(); // ID
        int hour = Integer.parseInt(tokenizer.nextToken());
        int min = Integer.parseInt(tokenizer.nextToken());
        int sec = Integer.parseInt(tokenizer.nextToken());
        int mill = Integer.parseInt(tokenizer.nextToken().substring(0,3));
        
        // Update the calendar
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, min);
        calendar.set(Calendar.SECOND, sec);
        calendar.set(Calendar.MILLISECOND, mill);
    }
    
    /**
     * Process a RMC NMEA message from the log file.
     *
     * @param line RMC message from the log file.
     * @param localTime Calendar object correctly initialized about hte local time, which is going to be updated according to the new line.
     * @param firstGPSFix The reference GPS fix which contains the initial match of local time and UTC-GPS time.
     * @return A new GPSFix object for the GPS fix.
     */
    private static GPSFix processRMCLine(String line, Calendar localTime, GPSFix firstGPSFix) throws GPSProcessorException {
        
        try {
            
            // Separate fields
            StringTokenizer tokenizer = new StringTokenizer(line, ",", false);
            
            /**
             * Get fields
             */
            
            tokenizer.nextToken(); // ID
            
            // Time of fix
            //System.out.println(line);
            String timeS = tokenizer.nextToken();
            int hour = Integer.parseInt(timeS.substring(0,2));
            int min = Integer.parseInt(timeS.substring(2,4));
            int sec = Integer.parseInt(timeS.substring(4,6));
            
            // Validity of values
            String validity = tokenizer.nextToken();
        /*if (!validity.equals("A"))
            return null;*/
            
            // Latitude
            String latitudeS = tokenizer.nextToken();
            float minutes = Float.parseFloat(latitudeS.substring(latitudeS.indexOf(".")-2)); // Minutes begin two digits just to the left of "."
            double lat = Double.parseDouble(latitudeS.substring(0, latitudeS.indexOf(".")-2)); // Initial part of the string are the degrees
            lat += minutes/60;
            String northS = tokenizer.nextToken(); // Check if coordinate is north or south
            int north = northS.equals("N")?1:-1;
            lat *= north;
            
            // Longitude
            String longitudeS = tokenizer.nextToken();
            minutes = Float.parseFloat(longitudeS.substring(longitudeS.indexOf(".")-2)); // Minutes begin two digits just to the left of "."
            double lon = Double.parseDouble(longitudeS.substring(0, longitudeS.indexOf(".")-2)); // Initial part of the string are the degrees
            lon += minutes/60;
            String eastS = tokenizer.nextToken(); // Check if coordinate is easth of west
            int east = eastS.equals("E")?1:-1;
            lon *= east;
            
            // Speed
            String speedS = tokenizer.nextToken();
            double speed = Double.parseDouble(speedS) * 1.852; // 1 Knot = 1.852 Km/h
            
            tokenizer.nextToken(); // Course
            
            // Parse the UTC date
            String dateS = tokenizer.nextToken();
            int day = Integer.parseInt(dateS.substring(0,2));
            int mon = Integer.parseInt(dateS.substring(2,4));
            int year = Integer.parseInt("20" + dateS.substring(4,6));
            
            /**
             * Update the local time.
             */
            
            // Create the UTC time of the fix
            GregorianCalendar fixTime = new GregorianCalendar(year, mon-1, day, hour, min, sec);
            
            // Set the rest of the date
            localTime.set(year, mon-1, day);
            
            // Update the local time according to the current offset regarding the first match with UTC-GPS time
            long offset = 0;
            if (firstGPSFix != null) {
                offset = fixTime.getTimeInMillis()-firstGPSFix.getFixTime();
                localTime.setTimeInMillis(firstGPSFix.getLocalTime()+offset);
            }
            
            /**
             * Create the wrapper object
             */
            
            GPSFix gpsFix = new GPSFix(fixTime.getTimeInMillis(), localTime.getTimeInMillis(), lat, lon, speed);
            return gpsFix;
            
        } catch (Exception e) {
            
            throw new GPSProcessorException("Error parsing GPS line: " + line);
        }
    }
}
