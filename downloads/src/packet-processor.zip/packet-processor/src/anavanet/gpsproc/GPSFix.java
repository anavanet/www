/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet.gpsproc;

import java.util.GregorianCalendar;

/**
 * This class represents a position of the vehicle (MR) in the VANET tests.
 *
 * @author Jos� Santa Lozano
 */
public class GPSFix {
    
    // UTC time of the related GPS fix
    private long fixTime;
    
    // Estimated local time
    private long localTime;
    
    // Latitude in degrees
    private double latitude;
    
    // Longitude in degrees
    private double longitude;
    
    // Speed in Km/h
    private double speed;
    
    /**
     * Creates a new GPSPosition object for a GPS fix.
     *
     * @param fixTime The UTC time of the GPS fix in Java milliseconds.
     * @param localTime The local time estimated for the fix in Java milliseconds.
     * @param speed The speed over the ground in Km/h
     */
    public GPSFix(long fixTime, long localTime, double latitude, double longitude, double speed) {
        
        this.fixTime = fixTime;
        this.localTime = localTime;
        this.latitude = latitude;
        this.longitude = longitude;
        this.speed = speed;
    }
    
    /**
     * Forwards the time of the GPS fix by the value given.
     *
     * @param The time to forward fix and local times.
     */
    public void forwardTime(long time) {
        
        fixTime += time;
        localTime += time;
    }
    
    /**
     * Modify the position by adding an offset.
     *
     * @param latitudeOffset The offset of the latitudes for each vehicle in degrees.
     * @praam longitudeOffset The offset of the longitudes for each vehicle in degrees.
     */
    public void movePosition(double latitudeOffset, double longitudeOffset) {
        
        latitude += latitudeOffset;
        longitude += longitudeOffset;
    }

    /**
     * Gets the UTC time of the related GPS fix.
     *
     * @return The time in Java milliseconds.
     */
    public long getFixTime() {
        
        return fixTime;
    }
    
    /**
     * Gets the estimated local time for the GPS fix.
     *
     * @return The time in Java milliseconds.
     */
    public long getLocalTime() {
        
        return localTime;
    }
    
    /**
     * Gets the latitude of the GPS position.
     *
     * @return The latitude in degrees.
     */
    public double getLatitude() {
        
        return latitude;
    }
    
    /**
     * Gets the longitude of the GPS position.
     *
     * @return The longitude in degrees.
     */
    public double getLongitude() {
        
        return longitude;
    }
    
    /**
     * Gets the speed over the ground.
     *
     * @return The speed in Km/h
     */
    public double getSpeed() {
        
        return speed;
    }
    
    public String toString() {
        
        String result = "";
        
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTimeInMillis(fixTime);
        result += "" + calendar.get(calendar.DAY_OF_MONTH) + "/" + (calendar.get(calendar.MONTH)+1) + "/" + calendar.get(calendar.YEAR);
        result += " " + calendar.get(calendar.HOUR_OF_DAY) + ":" + calendar.get(calendar.MINUTE) + ":" + calendar.get(calendar.SECOND);
        result += " ";
        calendar.setTimeInMillis(localTime);
        result += "" + calendar.get(calendar.DAY_OF_MONTH) + "/" + (calendar.get(calendar.MONTH)+1) + "/" + calendar.get(calendar.YEAR);
        result += " " + calendar.get(calendar.HOUR_OF_DAY) + ":" + calendar.get(calendar.MINUTE) + ":" + calendar.get(calendar.SECOND);
        result += " ";
        
        /*result += fixTime;
        result += " ";
        result += localTime;
        result += " ";*/
        result += latitude;
        result += " ";
        result += longitude;
        result += " ";
        result += speed;
        
        return result;
    }
    
    protected Object clone() {
        
        return new GPSFix(fixTime, localTime, latitude, longitude, speed);
    }    
}
