/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet.highLevelParser;

import java.io.*;
import java.util.*;

/**
 * Parser for IPerf output logs in UDP mode at server edge.
 *
 * @author Jos� Santa Lozano
 * @author Manabu Tsukada
 */
public class IPerfUDPParser {
    
    // Interval of each individual study in each line
    private static double FILE_INTERVAL = 0.5;
    
    private BufferedReader in;
    private int interval;
    
    /**
     * Creates a new instance of IPerfUDPParser.
     *
     * @param file The UDP log from IPerf.
     * @param interval The interval for getting information in seconds. IPerf data is every 0.5 seconds, but it can be grouped.
     */
    public IPerfUDPParser(File file, int interval) throws HighLevelParserException {

        try {
            in = new BufferedReader(new FileReader(file));
            
        } catch (FileNotFoundException e) {
            
            throw new HighLevelParserException("Error processing high level UDP log: " + e);
        }
        
        this.interval = interval;
    }
    
    /**
     * Obtain performance data for a period of time, from the log file.
     *
     * @return A wrapper object with the statistic information.
     */
    public PeriodInformation getPeriodInformation() throws HighLevelParserException {

        // Calculate the multiple of lines to process
        int nLines = (int)(interval/FILE_INTERVAL);
        // Get the required information
        PeriodInformation[] periodInformations = new PeriodInformation[nLines];
        for (int i=0; i<nLines; i++) {
            periodInformations[i] = processLine();
            if (periodInformations[i] == null)
                return null;
        }


        // Recalculate statistics
        long bytes = 0;
        long bandwidth = 0;
        double jitter = 0;
        for (int i=0; i<nLines; i++) {
            bytes += periodInformations[i].getBytes();
            bandwidth += periodInformations[i].getBandwidth();
            jitter += periodInformations[i].getJitter();
        }
        bandwidth /= nLines;
        jitter /= nLines;
        // Create the final wrapper object
        PeriodInformation periodInformation = new PeriodInformation(bytes, bandwidth, jitter);
        
        return periodInformation;
    }
    
    private PeriodInformation processLine() throws HighLevelParserException {
        
        String line = null;
        try {
            line = in.readLine();
        } catch (IOException e) {
            throw new HighLevelParserException("Error processing line from UDP Iperf log file: " + e);
        }

        //Check the end of the file
        if (line == null)
            return null;
        
        // Separate fields
        StringTokenizer stringTokenizer = new StringTokenizer(line, " ");
        
        // Skip initial lines
        if (!stringTokenizer.nextToken().equals("["))
            return processLine();
        
        // xx]
        stringTokenizer.nextToken();
        
        // Time interval
        String timeS = stringTokenizer.nextToken();
        if (timeS.equals("local"))
            return processLine();
        else if (timeS.startsWith("0.0") && !timeS.endsWith("-")) // Skip last summarizing lines
            return null;

        // Reach "bytes" field
        String currentToken = stringTokenizer.nextToken();
        String pastToken = null;
        while (!currentToken.equals("Bytes")) {
            pastToken = currentToken;
            try {
                currentToken = stringTokenizer.nextToken();
            } catch (NoSuchElementException e) {
                return processLine();
            }
        }
        long bytes = (long)Double.parseDouble(pastToken);
        
        // Bandwidth
        long bandwidth = (long)Double.parseDouble(stringTokenizer.nextToken());
        
        // bits/sec
        stringTokenizer.nextToken();
        
        // Jitter
        double jitter = Double.parseDouble(stringTokenizer.nextToken());

        // Create the resulting wrapper object
        PeriodInformation periodInformation = new PeriodInformation(bytes, bandwidth, jitter);
        
        return periodInformation;
    }
    
    public class PeriodInformation {
        
        private long bytes;
        private long bandwidth;
        private double jitter;
        
        public PeriodInformation (long bytes, long bandwidth, double jitter) {
            
            this.bytes = bytes;
            this.bandwidth = bandwidth;
            this.jitter = jitter;
        }

        public long getBytes() {
            return bytes;
        }

        public void setBytes(long bytes) {
            this.bytes = bytes;
        }

        public long getBandwidth() {
            return bandwidth;
        }

        public void setBandwidth(long bandwidth) {
            this.bandwidth = bandwidth;
        }

        public double getJitter() {
            return jitter;
        }

        public void setJitter(double jitter) {
            this.jitter = jitter;
        }
    }
}
