/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet.highLevelParser;

import java.io.*;
import java.util.*;

/**
 * Parser to extract information from output logs of IPerf in TCP mode.
 *
 * @author Jos� Santa Lozano
 */
public class IperfTCPParser {
    
    // Interval of each individual study in each line
    private static double FILE_INTERVAL = 0.5;
    
    private BufferedReader in;
    private int interval;
    
    /**
     * Creates a new instance of IPerfTCPParser.
     *
     * @param file The TCP log from IPerf.
     * @param interval The interval for getting information in seconds. IPerf data is every 0.5 seconds, but it can be grouped.
     */
    public IperfTCPParser(File file, int interval) throws HighLevelParserException {
        
        try {
            in = new BufferedReader(new FileReader(file));
            
        } catch (FileNotFoundException e) {
            
            throw new HighLevelParserException("Error processing high level TCP log: " + e);
        }
        
        this.interval = interval;
    }
    
    /**
     * Obtain performance data for a period of time, from the log file.
     *
     * @return A wrapper object with the statistic information.
     */
    public PeriodInformation getPeriodInformation() throws HighLevelParserException {
        
        // Calculate the multiple of lines to process
        int nLines = (int)(interval/FILE_INTERVAL);
        
        // Get the required information
        PeriodInformation[] periodInformations = new PeriodInformation[nLines];
        for (int i=0; i<nLines; i++) {
            periodInformations[i] = processLine();
            if (periodInformations[i] == null)
                return null;
        }
        
        // Recalculate statistics
        long bytes = 0;
        long bandwidth = 0;
        for (int i=0; i<nLines; i++) {
            bytes += periodInformations[i].getBytes();
            bandwidth += periodInformations[i].getBandwidth();
        }
        bandwidth /= nLines;

        
        // Create the final wrapper object
        PeriodInformation periodInformation = new PeriodInformation(bytes, bandwidth);
        
        return periodInformation;
    }
    
    private PeriodInformation processLine() throws HighLevelParserException {
        
        String line = null;
        try {
            line = in.readLine();
        } catch (IOException e) {
            throw new HighLevelParserException("Error processing line from TCP Iperf log file: " + e);
        }

        //Check the end of the file
        if (line == null)
            return null;
        
        // Separate fields
        StringTokenizer stringTokenizer = new StringTokenizer(line, " ");
        
        // Skip initial lines
        if (!stringTokenizer.nextToken().equals("["))
            return processLine();
        
        // xx]
        stringTokenizer.nextToken();
        
        // Time interval
        String timeS = stringTokenizer.nextToken();
        if (timeS.equals("local"))
            return processLine();
        else if (timeS.startsWith("0.0") && !timeS.endsWith("-")) // Skip last summarizing lines
            return null;

        // Reach "bytes" field
        String currentToken = stringTokenizer.nextToken();
        String pastToken = null;
        while (!currentToken.equals("Bytes")) {
            pastToken = currentToken;
            try {
                currentToken = stringTokenizer.nextToken();
            } catch (NoSuchElementException e) {
                return processLine();
            }
        }
        long bytes = (long)Double.parseDouble(pastToken);
        
        // Bandwidth
        long bandwidth = (long)Double.parseDouble(stringTokenizer.nextToken());
        
        // Create the resulting wrapper object
        PeriodInformation periodInformation = new PeriodInformation(bytes, bandwidth);
        
        return periodInformation;
    }
    
    public class PeriodInformation {
        
        private long bytes;
        private long bandwidth;
        
        public PeriodInformation (long bytes, long bandwidth) {
            
            this.bytes = bytes;
            this.bandwidth = bandwidth;
        }

        public long getBytes() {
            return bytes;
        }

        public void setBytes(long bytes) {
            this.bytes = bytes;
        }

        public long getBandwidth() {
            return bandwidth;
        }

        public void setBandwidth(long bandwidth) {
            this.bandwidth = bandwidth;
        }
    }
}
