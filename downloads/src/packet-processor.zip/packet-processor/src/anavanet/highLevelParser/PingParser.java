/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet.highLevelParser;

import anavanet.highLevelParser.IPerfUDPParser.PeriodInformation;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

/**
 * Parser for output logs from Ping tool.
 *
 * @author Jos� Santa Lozano
 * @author Manabu Tsukada
 */
public class PingParser {
    
    private BufferedReader in;
    
    /**
     * Creates a new instance of PingParser
     *
     * @param file The Ping log.
     */
    public PingParser(File file) throws HighLevelParserException {
        
        try {
            in = new BufferedReader(new FileReader(file));
            
        } catch (FileNotFoundException e) {
            
            throw new HighLevelParserException("Error processing high level log: " + e);
        }
    }
    
    /**
     * Obtain performance data for a second.
     *
     * @return The RTT in milliseconds. -1 if there is not information, 0 if the ping has been lost.
     */
    public PeriodInformation getPeriodInformation() throws HighLevelParserException {
        
        return processLine();
    }
    
    private PeriodInformation processLine() throws HighLevelParserException {
        
        String line = null;
        try {
            line = in.readLine();
        } catch (IOException e) {
            throw new HighLevelParserException("Error processing line from PING log file: " + e);
        }
        
        //Check the end of the file
        if (line == null)
            return null;
/*
 * Respuesta desde ::1: bytes=32 tiempo<1m
 * Respuesta desde ::1: bytes=32 tiempo<1m
 * Respuesta desde ::1: bytes=32 tiempo<1m
 * */
        
        // Search for interesting lines
        long bytes = 0;
        double rtt = 0;
        if (line.startsWith("64 bytes from")) {
            
            int iBytes = line.indexOf("bytes");
            int iTime = line.indexOf("time");

            if (iBytes != -1 && iTime != -1) {
                
                // Get delay info
//                bytes = Long.parseLong(line.substring(iBytes+6, line.indexOf("time")-1));
                bytes = 64;
                rtt = Double.parseDouble(line.substring(iTime+5, line.indexOf(" ms")));

            } else {
                return processLine();
            }
        } else if (line.startsWith("Tiempo de espera")) {  // Response from
            bytes = 32;
            rtt = -1;
        } else {
            return processLine();
        }

        // Create the resulting wrapper object
        PeriodInformation periodInformation = new PeriodInformation(bytes, rtt);
        
        return periodInformation;
    }
    
    public class PeriodInformation {
        
        private long bytes;
        private double rtt;
        
        public PeriodInformation(long bytes, double rtt) {
            
            this.bytes = bytes;
            this.rtt = rtt;
        }
        
        public long getBytes() {
            return bytes;
        }
        
        public void setBytes(long bytes) {
            this.bytes = bytes;
        }

        public double getRtt() {
            return rtt;
        }

        public void setRtt(double rtt) {
            this.rtt = rtt;
        }
        
    }
}
