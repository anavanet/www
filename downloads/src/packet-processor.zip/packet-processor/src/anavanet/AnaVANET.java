/*
 * Copyright (C) 2008 - Inria (France) / University of Murcia (Spain)
 *
 * Authors:
 * Manabu Tsukada (IMARA Project Team) <manabu.tsukada@inria.fr>
 * Jos� Santa Lozano (ANTS Researching Group) <josesanta@um.es>
 *
 * This file is part of AnaVANET-processor 
 *
 * AnaVANET-processor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * AnaVANET-processor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with AnaVANET-processor.  If not, see <http://www.gnu.org/licenses/>.
 */

package anavanet;

import anavanet.gpsproc.*;
import anavanet.highLevelParser.*;
import anavanet.packettrace.*;
import anavanet.statistics.*;
import java.io.*;
import java.util.Hashtable;
import java.util.Vector;

/**
 * Main class of the application to process logs collected from VANET tests.
 *
 */
public class AnaVANET {

    // Usage mode
    private static final String USAGE_MODE = "\nUsage:\t <execution_string> [-help] [<MR_ID MR_MAC dump_file_MR gps_file_MR> <MR_ID MR_MACdump_file_MR gps_file_MR> ...] (-UDP | -TCP | -PING) <high_level_file> -C2CNET -GN6 -NEMOSIG\n";
    // Base name to create output files with momentaneous distances between vehicles
    private static final String MOMENTANEOUS_DISTANCE_FILE = "distances.log";
    // Base name to create the output file with UDP Iperf packet traces
    private static final String UDP_TRACES_FILE = "UDPtraces.log";
    // Base name to create the output file with PING packet traces
    private static final String PING_TRACES_FILE = "PINGtraces.log";
    // Base name to create the output file with PING packet traces
    private static final String NEMOSIG_TRACES_FILE = "NEMOSigtraces.log";
    // Base name to create the output file which match UDP Iperf packets with vehicle position and distances
    private static final String UDP_TRACES_POSITION_FILE = "UDPtraces_position.xml";
    // Base name to create the output file which match PING packets with vehicle position and distances
    private static final String PING_TRACES_POSITION_FILE = "PINGtraces_position.xml";
    // Base name to create the output file which match TCP Iperf packets with vehicle position and distances
    private static final String TCP_TRACES_POSITION_FILE = "TCPtraces_position.xml";
    // Operation modes
    private static final int MODE_UDP = 0;
    private static final int MODE_TCP = 1;
    private static final int MODE_PING = 2;

    /**
     * Constructor of application.
     *
     * @param mode Operation mode of the program.
     * @param mrIds Identfiers of mobile routers. The first one is the source
     * MR.
     * @param mrMacs MAC addreses of mobile routers. The first one is the source
     * MR.
     * @param dumpFiles Dump network files for each MR. The first one is from
     * the source MR.
     * @param gpsFiles GPS logs for each MR. The first one is from the source
     * MR.
     * @param highLevelFile Log file with information from the performance tool
     * used.
     * @param c2c_mode
     * @param gn6_mode
     * @param nemo_signaling_mode
     * @param destMRNumFromLast
     */
    public AnaVANET(int mode, Vector<String> mrIds, Vector<String> mrMacs,
            Vector<File> dumpFiles, Vector<File> gpsFiles, File highLevelFile,
            boolean c2c_mode, boolean gn6_mode, boolean nemo_signaling_mode, int destMRNumFromLast) {

        /**
         * Process position logs
         */
        Vector<GPSFix[]> processedGPSLogs = new Vector<GPSFix[]>();
        for (File gpsFile : gpsFiles) {

            System.out.println("Processing GPS file: " + gpsFile.getName() + "...");

            try {
                // Process GPS log
                GPSFix[] processedLog = GPSProcessor.processGPSLog(gpsFile);

                // Check for discontinuities in the GPS fixes
                GPSFix[] discontinuities = GPSProcessor.checkFixContinuity(processedLog);
                for (int i = 0; i < discontinuities.length; i += 2) {
                    System.out.println("WARNING: Discontinuity in GPS match between vehicles detected:");
                    System.out.println("\tFROM: " + discontinuities[i]);
                    System.out.println("\tTO: " + discontinuities[i + 1]);
                }

                // Fill discontinuities
                processedLog = GPSProcessor.fillFixDiscontinuity(processedLog);

                // Check for discontinuities in the GPS fixes
                discontinuities = GPSProcessor.checkFixContinuity(processedLog);
                for (int i = 0; i < discontinuities.length; i += 2) {
                    System.out.println("**WARNING: Discontinuity in GPS match between vehicles detected:");
                    System.out.println("**\tFROM: " + discontinuities[i]);
                    System.out.println("**\tTO: " + discontinuities[i + 1]);
                }

                // Add the procesed fixes to the set
                processedGPSLogs.add(processedLog);
            } catch (GPSProcessorException e) {
                System.err.println("Error processing GPS log \"" + gpsFile.getName() + "\": " + e.getMessage());
                System.exit(-1);
            }

            System.out.println("Done");
        }

        // If we only have one log, all is done
        if (processedGPSLogs.size() < 2) {
            System.exit(0);
        }

        /**
         * Compute distances between consecutive vehicles (MR)
         */
        System.out.println("Matching GPS information and computing distances between vehicles...");

        // Calculate the distances
        GPSMatch[] gpsMatches = GPSProcessor.calculateMomentaneousGPSMatches(processedGPSLogs, mrIds);

        // Write distances in the output file
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter(new File(MOMENTANEOUS_DISTANCE_FILE)));

            for (GPSMatch gpsMatch : gpsMatches) {
                out.write(gpsMatch.toString() + "\n");
            }

            out.close();
        } catch (IOException e) {
            System.err.println("I/O error writing output file with distances: " + e.getMessage());
            System.exit(-1);
        }

        System.out.println("Done");

        /**
         * Process dump logs
         */
        Hashtable[] packetHashtables = new Hashtable[dumpFiles.size()];
        PacketInfo[] sentPacketsAtSrcMR = null;
        Vector<PacketInfo[]> sentPacketsAtDestMRs = new Vector<PacketInfo[]>(destMRNumFromLast);

        for (int i = 0; i < dumpFiles.size(); i++) {

            System.out.println("Processing dump file: " + dumpFiles.get(i).getName() + " i=" + i + "...");

            try {
                // Get reference date from a GPS fix in the same MR
                long refDate = processedGPSLogs.get(i)[0].getFixTime();
                PacketTracer packetTracer = new PacketTracer(dumpFiles.get(i), refDate);

                // Process log
                if (c2c_mode) {
                    packetTracer.C2cnetProcessDumpLog();
                } else if (gn6_mode) {
                    packetTracer.gn6ProcessDumpLog();
                } else {
                    packetTracer.processDumpLog();
                }

                // Save information
                packetHashtables[i] = packetTracer.getPacketHashtable();
                if (i == 0) {
                    sentPacketsAtSrcMR = packetTracer.getPacketInfos();
                } else if (i >= dumpFiles.size() - destMRNumFromLast) {     // multiple Dest
                    sentPacketsAtDestMRs.add(packetTracer.getPacketInfos());
                }

            } catch (PacketTracerException e) {
                System.err.println("Error processing dump log \"" + dumpFiles.get(i).getName() + "\": " + e.getMessage());
                System.exit(-1);
            }

            System.out.println("Done");
        }

        // These value used in UDP, TCP, ICMP
        PacketTrace[] NEMOSigPacketTraces = null;
        Vector<long[]> BULocalTime = null;
        int[] NEMOStatuses = null;

        ////////////////////////////////////////////////////////
        ////////////////// NEMO SIGNALING //////////////////////
        ////////////////////////////////////////////////////////

        if (nemo_signaling_mode == true) {
            System.out.println("Tracing NEMO Signaling packets sent at source MR...");

            NEMOSigPacketTraces = PacketTracer.traceTwoWayPackets(sentPacketsAtSrcMR,
                    sentPacketsAtDestMRs, packetHashtables, mrIds, mrMacs, destMRNumFromLast, PacketInfo.TYPE_NEMO_BU);

            // Write the traces in the output file
            try {
                BufferedWriter out = new BufferedWriter(new FileWriter(new File(NEMOSIG_TRACES_FILE)));

                for (int i = 0; i < NEMOSigPacketTraces.length; i++) {
                    out.write(NEMOSigPacketTraces[i].toString() + "\n");
                }

                out.close();
            } catch (IOException e) {
                System.err.println("I/O error writing traces file: " + e.getMessage());
                System.exit(-1);
            }

            System.out.println("Done");


            BULocalTime = new Vector<long[]>(NEMOSigPacketTraces.length);
            NEMOStatuses = new int[NEMOSigPacketTraces.length];
            for (int i = 0; i < NEMOSigPacketTraces.length; i++) {
                NEMOStatuses[i] = 2;                          // BU sent, not sure BA receives
                BULocalTime.add(NEMOSigPacketTraces[i].getLocalTimes());
                String[] Nexthops = NEMOSigPacketTraces[i].getNextHops();
                for (int m = 0; m < Nexthops.length; m++) {
                    if (Nexthops[m].equals(mrIds.get(0) + "x")) {           // if there is source MR + x, BA received
                        NEMOStatuses[i] = 1;
                    }
                }
            }
        }

        //////////////////////////////////////////////
        ////////////////// UDP ///////////////////////
        //////////////////////////////////////////////

        if (mode == MODE_UDP) {

            /**
             * Trace UDP packets from IPerf
             */
            System.out.println("Tracing UDP IPerf packets sent at source MR...");
            PacketTrace[] iperfPacketTraces = PacketTracer.traceIperfPackets(sentPacketsAtSrcMR, packetHashtables, mrIds, mrMacs, destMRNumFromLast);

            // Write the traces in the output file
            try {
                BufferedWriter out = new BufferedWriter(new FileWriter(new File(UDP_TRACES_FILE)));

                for (int i = 0; i < iperfPacketTraces.length; i++) {

                    out.write(iperfPacketTraces[i].toString() + "\n");
                }

                out.close();
            } catch (IOException e) {
                System.err.println("I/O error writing traces file: " + e.getMessage());
                System.exit(-1);
            }

            System.out.println("Done");

            /**
             * Match UDP traces with vehicle positions and distances.
             */
            System.out.println("Calculating statistics for UDP traces according to GPS information...");

            // Extract necessary information from previous studies
            long[] packetIds = new long[iperfPacketTraces.length];
            Vector<String[]> mobileRouters = new Vector<String[]>(iperfPacketTraces.length);
            Vector<long[]> localTimes = new Vector<long[]>(iperfPacketTraces.length);
            Vector<String[]> nextHops = new Vector<String[]>(iperfPacketTraces.length);
            int[] lengths = new int[iperfPacketTraces.length];
            for (int i = 0; i < iperfPacketTraces.length; i++) {
                packetIds[i] = iperfPacketTraces[i].getPacketInfo().getId();
                mobileRouters.add(iperfPacketTraces[i].getMobileRouters());
                localTimes.add(iperfPacketTraces[i].getLocalTimes());
                nextHops.add(iperfPacketTraces[i].getNextHops());
                lengths[i] = iperfPacketTraces[i].getPacketInfo().getLength();
            }

            long[] utcTimes = new long[gpsMatches.length];
            Vector<long[]> gpsLocalTimes = new Vector<long[]>(gpsMatches.length);
            Vector<double[]> latitudes = new Vector<double[]>(gpsMatches.length);
            Vector<double[]> longitudes = new Vector<double[]>(gpsMatches.length);
            Vector<double[]> speeds = new Vector<double[]>(gpsMatches.length);
            Vector<double[]> distances = new Vector<double[]>(gpsMatches.length);
            for (int i = 0; i < gpsMatches.length; i++) {
                utcTimes[i] = gpsMatches[i].getFixTime();
                gpsLocalTimes.add(gpsMatches[i].getLocalTimes());
                latitudes.add(gpsMatches[i].getLatitudes());
                longitudes.add(gpsMatches[i].getLongitudes());
                speeds.add(gpsMatches[i].getSpeeds());
                distances.add(gpsMatches[i].getDistances());
            }

            // Calculate statistics
            StatisticInfo[] statisticIperfInfos = Statistic.calculateStatistics(packetIds,
                    mobileRouters, localTimes, nextHops, lengths, utcTimes, gpsLocalTimes, latitudes, longitudes,
                    speeds, distances, mrIds, BULocalTime, NEMOStatuses);

            System.out.println("Done");

            /**
             * Join low level information with high level information from
             * Iperf.
             */
            System.out.println("Joining UDP high level information from IPerf tool...");

            // Search for the beggining of the UDP transmission
            int i = 0;
            for (i = 0; i < statisticIperfInfos.length && statisticIperfInfos[i].getPDR() == -1; i++);


            // Complete statistic info with IPerf information
            try {
                IPerfUDPParser iperfUDPParser = new IPerfUDPParser(highLevelFile, 1);
                IPerfUDPParser.PeriodInformation udpPeriodInformation = null;
                System.out.println("statisticIperfInfos.length !!! " + statisticIperfInfos.length);
                while ((udpPeriodInformation = iperfUDPParser.getPeriodInformation()) != null
                        && i < statisticIperfInfos.length) {   //  C2C NET makes packet bigger
                    statisticIperfInfos[i].setBytes(udpPeriodInformation.getBytes());
                    statisticIperfInfos[i].setBandwidth(udpPeriodInformation.getBandwidth());
                    statisticIperfInfos[i].setJitter(udpPeriodInformation.getJitter());
                    i++;
                }
            } catch (HighLevelParserException e) {
                System.err.println("Error processing high level UDP log from IPerf: " + e.getMessage());
                System.exit(-1);
            }

            // Print output in a file
            try {
                BufferedWriter out = new BufferedWriter(new FileWriter(new File(UDP_TRACES_POSITION_FILE)));
                out.write("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n");
                out.write("<markers>\n");
                for (i = 0; i < statisticIperfInfos.length; i++) {
                    out.write(statisticIperfInfos[i].toString() + "\n");
                }
                out.write("</markers>\n");

                out.close();
            } catch (IOException e) {
                System.err.println("I/O error writing UDP statistics file: " + e.getMessage());
                System.exit(-1);
            }

            System.out.println("Done");

            //////////////////////////////////////////////
            ////////////////// TCP ///////////////////////
            //////////////////////////////////////////////

        } else if (mode == MODE_TCP) {

            /**
             * Get statistic values only from GPS traces.
             */
            // Create statistic wrappers
            StatisticInfo[] statisticIperfInfos = new StatisticInfo[gpsMatches.length];
            for (int i = 0; i < gpsMatches.length; i++) {
                int NEMO_status = 0;
                for (int m = 0; m < NEMOStatuses.length; m++) {
                    if ((gpsMatches[i].getLocalTimes()[0] - 1000) <= BULocalTime.get(m)[0] && BULocalTime.get(m)[0] < gpsMatches[i].getLocalTimes()[0]) {
                        // NEMO_status recorded in the second.
                        System.out.println("NEMOStatuses == " + NEMOStatuses[m]);
                        NEMO_status = NEMOStatuses[m];
                    }
                }
                statisticIperfInfos[i] = new StatisticInfo(gpsMatches[i].getFixTime(), gpsMatches[i].getLocalTimes()[0],
                        mrIds.toArray(new String[0]), gpsMatches[i].getLatitudes(), gpsMatches[i].getLongitudes(),
                        gpsMatches[i].getSpeeds(), gpsMatches[i].getDistances(), NEMO_status);
            }
            System.out.println("gpsMatches.length ==" + gpsMatches.length);
            /**
             * Join low level information with high level information from
             * Iperf.
             */
            System.out.println("Joining TCP high level information from IPerf tool...");

            // Search for the beggining of the TCP transmission
            PacketInfo initialPacketInfo = sentPacketsAtSrcMR[0];
            int i = 0;
            for (; i < statisticIperfInfos.length && statisticIperfInfos[i].getLocalTime() < initialPacketInfo.getLocalTime(); i++);

            // Complete statistic info with IPerf information
            try {
                IperfTCPParser iperfTCPParser = new IperfTCPParser(highLevelFile, 1);
                IperfTCPParser.PeriodInformation tcpPeriodInformation = null;
                while ((tcpPeriodInformation = iperfTCPParser.getPeriodInformation()) != null) {

                    statisticIperfInfos[i].setBytes(tcpPeriodInformation.getBytes());
                    statisticIperfInfos[i].setBandwidth(tcpPeriodInformation.getBandwidth());
                    i++;
                }
            } catch (HighLevelParserException e) {
                System.err.println("Error processing high level TCP log from IPerf: " + e.getMessage());
                System.exit(-1);
            }

            // Print output in a file
            try {
                BufferedWriter out = new BufferedWriter(new FileWriter(new File(TCP_TRACES_POSITION_FILE)));

                out.write("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n");
                out.write("<markers>\n");
                for (i = 0; i < statisticIperfInfos.length; i++) {
                    out.write(statisticIperfInfos[i].toString() + "\n");
                }
                out.write("</markers>\n");

                out.close();
            } catch (IOException e) {
                System.err.println("I/O error writing TCP statistics file: " + e.getMessage());
                System.exit(-1);
            }

            System.out.println("Done");

            //////////////////////////////////////////////
            ////////////////// PING //////////////////////
            //////////////////////////////////////////////

        } else if (mode == MODE_PING) {

            /**
             * Trace PING packets
             */
            System.out.println("Tracing PING packets sent at source MR...");

            PacketTrace[] pingPacketTraces = PacketTracer.traceTwoWayPackets(sentPacketsAtSrcMR,
                    sentPacketsAtDestMRs, packetHashtables, mrIds, mrMacs, destMRNumFromLast, PacketInfo.TYPE_ICMP_REQ);

            // Write the traces in the output file
            try {
                BufferedWriter out = new BufferedWriter(new FileWriter(new File(PING_TRACES_FILE)));

                for (int i = 0; i < pingPacketTraces.length; i++) {
                    out.write(pingPacketTraces[i].toString() + "\n");
                }

                out.close();
            } catch (IOException e) {
                System.err.println("I/O error writing traces file: " + e.getMessage());
                System.exit(-1);
            }

            System.out.println("Done");

            /**
             * Match PING traces with vehicle positions and distances.
             */
            System.out.println("Calculating statistics for PING traces according to GPS information...");

            // Extract necessary information from previous studies
            long[] packetIds = new long[pingPacketTraces.length];
            Vector<String[]> mobileRouters = new Vector<String[]>(pingPacketTraces.length);
            Vector<long[]> localTimes = new Vector<long[]>(pingPacketTraces.length);
            Vector<String[]> nextHops = new Vector<String[]>(pingPacketTraces.length);
            int[] lengths = new int[pingPacketTraces.length];
            for (int i = 0; i < pingPacketTraces.length; i++) {
                packetIds[i] = pingPacketTraces[i].getPacketInfo().getId();
                mobileRouters.add(pingPacketTraces[i].getMobileRouters());
                localTimes.add(pingPacketTraces[i].getLocalTimes());
                nextHops.add(pingPacketTraces[i].getNextHops());
                lengths[i] = pingPacketTraces[i].getPacketInfo().getLength();
            }
            long[] utcTimes = new long[gpsMatches.length];
            Vector<long[]> gpsLocalTimes = new Vector<long[]>(gpsMatches.length);
            Vector<double[]> latitudes = new Vector<double[]>(gpsMatches.length);
            Vector<double[]> longitudes = new Vector<double[]>(gpsMatches.length);
            Vector<double[]> speeds = new Vector<double[]>(gpsMatches.length);
            Vector<double[]> distances = new Vector<double[]>(gpsMatches.length);
            for (int i = 0; i < gpsMatches.length; i++) {
                utcTimes[i] = gpsMatches[i].getFixTime();
                gpsLocalTimes.add(gpsMatches[i].getLocalTimes());
                latitudes.add(gpsMatches[i].getLatitudes());
                longitudes.add(gpsMatches[i].getLongitudes());
                speeds.add(gpsMatches[i].getSpeeds());
                distances.add(gpsMatches[i].getDistances());
            }
            // Calculate statistics
            StatisticInfo[] statisticPingInfos = Statistic.calculateStatistics(packetIds,
                    mobileRouters, localTimes, nextHops, lengths, utcTimes, gpsLocalTimes, latitudes, longitudes,
                    speeds, distances, mrIds, BULocalTime, NEMOStatuses);

            System.out.println("Done");

            /**
             * Join low level information with high level information from Ping.
             */
            System.out.println("Joining high level information from Ping tool...");
            // Search for the beggining of the PING transmission
            int i = 0;
            for (; i < statisticPingInfos.length && statisticPingInfos[i].getRtt() == -1; i++) {
            }


            // Complete statistic info with IPerf information
            try {
                PingParser pingParser = new PingParser(highLevelFile);
                PingParser.PeriodInformation pingPeriodInformation = null;

                while ((pingPeriodInformation = pingParser.getPeriodInformation()) != null
                        && i < statisticPingInfos.length) {

                    statisticPingInfos[i].setBytes(pingPeriodInformation.getBytes());
                    statisticPingInfos[i].setBandwidth(-1);
                    statisticPingInfos[i].setJitter(-1);
                    statisticPingInfos[i].setE2eRtt(pingPeriodInformation.getRtt());
                    // Check if more than one packet has been logged for the current second
                    for (int j = 1; j < statisticPingInfos[i].getLoggedPackets(); j++) {
                        pingPeriodInformation = pingParser.getPeriodInformation();
                    }

                    i++;

                    // Skip periods without any packet emitted
                    for (; i < statisticPingInfos.length && statisticPingInfos[i].getPDR() == -1; i++);
                }
            } catch (HighLevelParserException e) {
                System.err.println("Error processing high level PING log from tool: " + e.getMessage());
                System.exit(-1);
            }


            // Print output in a file
            try {
                BufferedWriter out = new BufferedWriter(new FileWriter(new File(PING_TRACES_POSITION_FILE)));

                out.write("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n");
                out.write("<markers>\n");
                for (i = 0; i < statisticPingInfos.length; i++) {
                    out.write(statisticPingInfos[i].toString() + "\n");
                }
                out.write("</markers>\n");

                out.close();
            } catch (IOException e) {
                System.err.println("I/O error writing PING statistics file: " + e.getMessage());
                System.exit(-1);
            }

            System.out.println("Done");
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int mode = 0;
        boolean c2c_mode = false;
        boolean gn6_mode = false;
        boolean nemo_signaling_mode = false;
        int destMRNumFromLast = 1;

        Vector<String> mrIds = new Vector<String>();
        Vector<String> mrMacs = new Vector<String>();
        Vector<File> dumpFiles = new Vector<File>();
        Vector<File> gpsFiles = new Vector<File>();
        File highLevelFile = null;

        // Process input arguments
        try {

            for (int i = 0; i < args.length; i++) {

                if (args[i].equals("-help")) {
                    System.out.println(USAGE_MODE);
                    System.exit(0);

                } else if (args[i].equals("-UDP")) {

                    mode = MODE_UDP;
                    highLevelFile = new File(args[++i]);
                } else if (args[i].equals("-TCP")) {
                    mode = MODE_TCP;
                    highLevelFile = new File(args[++i]);
                } else if (args[i].equals("-PING")) {
                    mode = MODE_PING;
                    highLevelFile = new File(args[++i]);
                } else if (args[i].equals("-C2CNET")) { // C2C
                    c2c_mode = true;
                } else if (args[i].equals("-GN6")) { // GN6
                    gn6_mode = true;
                } else if (args[i].equals("-NEMOSIG")) { // NEMOSIG
                    nemo_signaling_mode = true;
                } else if (args[i].equals("-DESTMR")) { // DESTMR
                    destMRNumFromLast = Integer.parseInt(args[i + 1]);
                    i++;
                } else {
                    // Open a pair of dump and gps files for one MR
                    String mrId = args[i++];
                    String mrMac = args[i++];
                    File dumpFile = new File(args[i++]);
                    File gpsFile = new File(args[i]);
                    if (!dumpFile.canRead() || !gpsFile.canRead()) {
                        throw new IOException("Files cannot be read");
                    }

                    mrIds.add(mrId);
                    mrMacs.add(mrMac);
                    dumpFiles.add(dumpFile);
                    gpsFiles.add(gpsFile);
                }
            }

        } catch (IOException e) {
            System.err.println("\nI/O error: " + e.getMessage());
            System.exit(-1);
        } catch (Exception e) {
            System.out.println("\nMaybe your are not following the invocation sintax.");
            System.out.println(USAGE_MODE);
            System.exit(-1);
        }

        // Call the processing application
        new AnaVANET(mode, mrIds, mrMacs, dumpFiles, gpsFiles, highLevelFile, c2c_mode, gn6_mode, nemo_signaling_mode, destMRNumFromLast);
    }
}
