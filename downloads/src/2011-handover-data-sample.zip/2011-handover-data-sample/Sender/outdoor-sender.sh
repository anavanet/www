#!/bin/sh

IF=eth0
IP_ADDR=2001:660:3013:CA04::2/64
GW_ADDR=2001:660:3013:CA04::1
#DST=2001:660:3013:3:20d:56ff:febd:cd4f # fylvestre
#DST=2001:660:3013:f001::1		# gw
DST=2001:660:3013:f004::3		# ha
#DST=2001:660:3013:f004::ca05		# rsu1
TEST_ID=`date "+%Y%m%d-%H-%M-%N"`

IPERF_T=900
IPERF_Band=1000000
IPERF_LEN=1250


echo "==== $1 Testing ======="

ip -6 addr add $IP_ADDR dev $IF

case $1 in
    "-TCP")
        filename=./logs/TCP_Sender_$TEST_ID.log
	iperf --client $DST --format b -i .5 -V --time 900 -M 1230 -m >>  $filename | tail -f $filename;;
    "-UDP")
        filename=./logs/UDP_Sender_$TEST_ID.log
	iperf --client $DST --udp --format b -i .5 -V --time $IPERF_T --bandwidth $IPERF_Band --len $IPERF_LEN >>  $filename | tail -f $filename;;
    "-PING")
        filename=./logs/ICMP_Sender_$TEST_ID.log
	ping6 -i 0.5  $DST >> $filename | tail -f $filename
	echo ;;
    *)
        echo "Invalid option. You have to choose between \"-UDP\", \"-TCP\" or \"-PING\" "
        echo
        exit;;
esac

