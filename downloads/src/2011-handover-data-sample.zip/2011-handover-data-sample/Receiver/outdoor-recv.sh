
#!/bin/sh

IF=eth0
IP_ADDR=2001:660:3013:f004::3
GW_ADDR=2001:660:3013:CA06::1
DST=2001:660:3013:CA03::2
TEST_ID=`date "+%Y%m%d-%H-%M-%N"`

echo "==== $1 Testing ======="

case $1 in
    "-TCP")
	    filename=./logs/TCP_Sender_$TEST_ID.log
	    iperf -s --format b -i .5 -V --bind $IP_ADDR >>  $filename | tail -f $filename;;
    "-UDP")
	    filename=./logs/UDP_Sender_$TEST_ID.log
	    iperf -s --udp --format b -i .5 -V --bind $IP_ADDR >>  $filename | tail -f $filename;;
    *)
     echo "Invalid option. You have to choose between \"-UDP\" or \"-TCP\" "
echo
exit;;
esac

