modprobe -r ath_pci
sleep 1
modprobe ath_pci autocreate=adhoc
sleep 1
iwconfig ath2 essid itsnet channel 3 mode Ad-hoc rate 6M 
#iwconfig ath2 essid itsnet channel 149 mode Ad-hoc rate 6M 
sleep 1
ifconfig ath2 up
