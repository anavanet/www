#!/bin/bash

OBU_ID=RSU
BASE_DIR=/root/imara-espritec
SCRIPT_DIR=$BASE_DIR/Scripts/outdoor-test/$OBU_ID
Egress_IF=ath1
VERSION=0.9.8

# === Software ===
Tunctl=$BASE_DIR/Sources/others/tunctl-1.5/tunctl 
ITSNET=$BASE_DIR/Sources/itsnet-v$VERSION/src/itsnet
GPS_SENDER=$BASE_DIR/Sources/itsnet-v$VERSION/gps-data-sender/gps_position_sender
PositionSensor=$BASE_DIR/Sources/itsnet-v$VERSION/position-sensor/position_sensor
MIP6D=$BASE_DIR/Sources/mip6d-v0.4-itsnet-v0.9.5/src/mip6d 
GPSD=/usr/sbin/gpsd
MNPPD=/root/imara-espritec/Sources/mnpp/radvd-v1.5-mnpp-v0.3/radvd 
RADVD=/usr/local/sbin/radvd

# === config ===
RADVD_CONF=$SCRIPT_DIR/radvd.conf
MNPP_CONF=$SCRIPT_DIR/mnppd.conf
ITSNET_CONF=$SCRIPT_DIR/itsnet.conf
MIP6D_CONF=$SCRIPT_DIR/mip6d.conf
GPS_SENDER_CONF=$SCRIPT_DIR/imara-bt7.txt

#===== Interfaces =====
Ingress_IF=eth0
TUNNEL=tun0

#===== Addresses =====
TunnelLinkLocal=fe80::ca05/64                   # for NEMO
InVehicleNetwork=2001:660:3013:CA05::/64
TunnelAddress=2001:660:3013:F005::CA05/64

StaticRSUDestPrefix=2001:660:3013:CA04::/64
StaticRSUIPNextHop=2001:660:3013:F005::CA04

#==== GPS =========
WithGPS=yes
PositionSensorDevice=/dev/ttyS0 	# Serial port used to connect GPS serial cable

#===== Static conf for AnaVANET ===
AnaVANET=yes
SERIAL_SPEED=38400			# 57600 / 9600 ?
PCAP_FILE=tcpdump 			# Base name of the output tcpdump files
GPS_FILE=gps				# Base name of the GPS output
MAC_ADDR="00:06:80:00:a6:bd"   		# RSU
lat=4850.262114
lon=00206.07544106

# set the cell ID (what is this?)
# iwconfig $Egress_IF ap 00:11:22:33:44:55

######### IPC2C Configuration ###########
sh kill.sh
/usr/sbin/ntpdate 2001:2f8:29:100::fff4

# tap0
echo "tap0 config"
modprobe -r tun; sleep 1; modprobe tun;
$Tunctl -t $TUNNEL -n # point-to point
#ip link set $TUNNEL arp off
ip link set $TUNNEL arp on
echo "Tunneling interface mounted"
sysctl -w net.ipv6.conf.all.forwarding=1

ifconfig $TUNNEL inet6 add $TunnelLinkLocal up
ifconfig $Egress_IF up
ifconfig $TUNNEL inet6 add $TunnelAddress up
ifconfig $TUNNEL mtu 1350 up
echo "Tunnel address configured"

# ====== static route ======
ip -6 route add $StaticRSUDestPrefix via $StaticRSUIPNextHop dev $TUNNEL 
ip -6 route change $StaticRSUDestPrefix via $StaticRSUIPNextHop dev $TUNNEL 

sysctl -w net.ipv6.neigh.$TUNNEL.mcast_solicit=1
echo "route set for V2V communication "

#======GPS SPEED======
echo "Fake GPS mode"
$GPS_SENDER -c $GPS_SENDER_CONF &

#===============AnaVAMET START===============
if [ $AnaVANET = 'yes' ]; then

#====== Time setup =====
TEST_ID=`date "+%Y%m%d-%H-%M-%N"` # for file name
filename=./logs/$GPS_FILE"_"MR"_"$TEST_ID".log"
DATE=`date +%d%m%y`
TIME=`date +%H%M%S`
TIME=`expr $TIME - 10000`

# Start logging the position from GPS
#echo "Starting GPS logging..."
#/bin/stty $SERIAL_SPEED cs8 -parenb crtscts -echo -F $PositionSensorDevice
#
#if [ $WithGPS = 'yes' ]; then # With GPS
#	echo "GPS mode"
#	$GPSD -N $PositionSensorDevice &
#	$PositionSensor &
#fi
#sleep 1
#echo "connecting gpsd........."
#exec 3<>/dev/tcp/localhost/2947
#echo -e "?WATCH={\"raw\":1}">&3
#cat <&3 >> $filename &
#echo "connecting gpsd.........done"


echo $TEST_ID >> ./logs/test-memo.txt

date '+TIME:%H:%M:%S:%N' >> $filename

for (( i=0; i<1000; i++ ))  # Stablish a synchronization point between GPS time and local time
do
	echo "\$GPRMC,$TIME,A,$lat,N,$lon,E,000.00,251.2,$DATE,4.0,W,D*3A" >> $filename
	echo -n "*"
        TIME=`expr $TIME + 1`
done
echo 
echo "OK"

# Start tcpdump listen
echo "Starting tcpdump listening..."
filename=./logs/$PCAP_FILE"_"MR"_"$TEST_ID".log"
/usr/sbin/tcpdump -s1500 -ni $Egress_IF -w $filename wlan host $MAC_ADDR &
echo "OK"

fi 


#===============AnaVAMET EMD===============



#====== ITSNET ======

#$MIP6D -m -c $MIP6D_CONF & #-l /var/log/mip6d.log &
$RADVD -C $RADVD_CONF

while true;
do

	# C2C NET
	echo "==== C2C NET ===="
	sleep 0.1
	$ITSNET -m -c $ITSNET_CONF 
done
