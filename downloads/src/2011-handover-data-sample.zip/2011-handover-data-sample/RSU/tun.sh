
OBU_ID=OBU3
BASE_DIR=/root/manabu-thesis-ITSNET # Working directory and container of some necessary tools
Tunctl=$BASE_DIR/Softwares/tunctl-1.5/tunctl 

# tap0
modprobe tun
echo "tap0 config"
ifconfig tun0 down
$Tunctl -d tun0
