#!/usr/bin/perl
use strict;
use warnings;
use lib qw/ lib /;
use NMEA::Parser;

my $file   = "../../data/2012-09-18-RSSI-test/gps.txt";
# timezone '+2' means CEST (summer time in France)
my $parser = NMEA::Parser->new({ file => $file, timezone => '+2' }); 

print $parser->parse_all_csv;
#print $parser->parse_all_json;
