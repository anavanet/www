package TCPdump::Parser;
use strict;
use warnings;
use lib qw/ lib /;
use JSON::XS;
use Math::Decibel qw/ decibel_avg /;
use Class::Accessor::Lite (
    rw  => [ qw/ file / ]
    );

sub new {
    my $self    = shift;
    my $arg_ref = shift || {};
    bless $arg_ref, $self;
}


# - tcpdump format example
# 2012-09-18 15:08:14.644890 458533296us tsft 6.0 Mb/s 5900 MHz 11a -50dB signal antenna 1 [bit 14] 
# CF +QoS IP6 fe80::21b:b1ff:feb5:e737.55492 > ff02::1:12:24:200.5001: UDP, length 200

#----------------------------------------
sub get_all_rssi_ref {
    my $self = shift;
    return unless -e $self->file;

    my $fh;
    my $cache_flag = 1;
    if( my $cache_file = _is_cache_file( $self->file ) ) {
        $cache_flag = 0;
        open $fh, "<", $cache_file;
    }
    else {
        my $file = $self->file;
        open $fh, "tcpdump -ttttnnr $file |" or die "Can not open file/tcpdump\n";
    }

    my $results = [];
    my @tmp_rssi;
    my $before_sec;
    my $date;
    my $time;
    my $rssi;
    while( my $line = <$fh> ) {
        if( $line =~ m/^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})\.\d{6}.+(-\d{2,3}[.\d]*)dB signal/ ) {
            $date = $1;
            $time = $2;
            $rssi = $3;

            # checking change of value of 'sec'
            if( 0 < scalar(@tmp_rssi) && $time ne $before_sec ) {
                my $rssi_ref = {
                    date => $date,
                    time => $before_sec,
                    rssi => decibel_avg( @tmp_rssi )
                };
                #printf("%s,%s,%.1f dB\n", $rssi_ref->{date}, $rssi_ref->{time}, $rssi_ref->{rssi});
                push @$results, $rssi_ref;
                @tmp_rssi = ();
            }
            $before_sec = $time;
            push @tmp_rssi, $rssi;
        }
    }
    my $rssi_ref = {
        date => $date,
        time => $time,
        rssi => decibel_avg( @tmp_rssi )
    };
    push @$results, $rssi_ref;
    close $fh;

    if( $cache_flag ) {
        _save_cache_file( $results );
    }
    return $results;
}

#----------------------------------------
sub get_all_rssi_csv {
    my $self = shift;
    my $result_csv = "date,time,rssi\n";
    my $all_ref = $self->get_all_rssi_ref();
    for my $rssi_ref (@$all_ref) {
        $result_csv .= sprintf("%s,%s,%.1f\n", $rssi_ref->{date}, $rssi_ref->{time}, $rssi_ref->{rssi});
    }
    return $result_csv;
}

#----------------------------------------
sub _save_cache_file {
    my $all_date_ref = shift;
    my $first_ref = $all_date_ref->[0];
    my $file = sprintf("%s_%s_%.0f.dat", $first_ref->{date}, $first_ref->{time}, $first_ref->{rssi});
    $file =~ tr/:/-/;

    mkdir "./.cache/" unless -d "./.cache/";
    open my $fh, ">", "./.cache/$file";
    for my $rssi_ref (@$all_date_ref) {
        print $fh sprintf("%s %s.000000 %.1fdB signal\n", $rssi_ref->{date}, $rssi_ref->{time}, $rssi_ref->{rssi});
    }
}

#----------------------------------------
sub _is_cache_file {
    my $file = shift;
    return unless -e $file;

    open my $fh, "tcpdump -ttttnnr $file | head -1 |" or die "Can not open file/tcpdump\n";
    my $line = <$fh>;
    close $fh;

    if( $line =~ m/^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2}:\d{2})\.\d{6}.+(-\d{2,3})dB signal/ ) {
        my $date = $1;
        my $time = $2;
        my $rssi = $3;
        my $file = sprintf("%s_%s_%.0f.dat", $date, $time, $rssi);
        $file =~ tr/:/-/;
        my $cache_file = "./.cache/$file";
        return $cache_file if -e $cache_file;
    }
    return;
}

1;
