package Math::Decibel;
use strict;
use warnings;
use base 'Exporter';
our @EXPORT_OK = qw/ decibel_avg /;

#----------------------------------------
sub decibel_avg {
    my @numbers = @_;
    my $total = 0;
    for my $num (@numbers) {
        $total += 10**($num / 10.0);
    }
    return 10*log10($total / scalar( @numbers ));
}

#----------------------------------------
sub log10 {
    my $n = shift;
    return log($n)/log(10);
}

1;
