package NMEA::Parser;
use JSON::XS;
use Class::Accessor::Lite (
    rw  => [ qw/ file timezone / ]
    );

sub new {
    my $self    = shift;
    my $arg_ref = shift || {};
    bless $arg_ref, $self;
}

sub parse_all_ref {
    my $self = shift;
    return unless -e $self->file;
    open my $fh, "<", $self->file;

    my $tz = $self->timezone || 0;
    my $results = [];
    while( my $line = <$fh> ) {
        next unless $line =~ /^\$GPRMC/;
        chomp $line;
        my @param = split(/,/, $line);

        # time
        my ($h, $m, $s) = $param[1] =~ m/^(\d{2})(\d{2})(\d{2})\./;
        my ($day, $month, $year) = $param[9] =~ m/^(\d{2})(\d{2})(\d{2})/;
        $year += 2000;
        $h += $tz;
        if( $h > 23 ) {
            my $wrong_time = sprintf("%4d-%02d-%02d %02d:%02d:%02d");
            die("wrong hour is found\n$wrong_time\nhave to fix the code to consider date\n") 
        }

        # latitude
        my ($deg_lat, $min_lat) = $param[3] =~ m/^(\d{2})([\d.]{7})$/;
        my $dir_lat = $param[4];
        my $lat = sprintf("%.7f", $deg_lat + $min_lat / 60.0);
        $lat = -$lat if $dir_lat eq 'S';

        # longitude 
        my ($deg_lon, $min_lon) = $param[5] =~ m/^(\d{3})([\d.]{7})$/;
        my $dir_lon = $param[6];
        my $lon = sprintf("%.7f", $deg_lon + $min_lon / 60.0);
        $lon = -$lon if $dir_lon eq 'W';

        #print "$year-$month-$day,$h:$m:$s,$lat,$lon\n";
        push @$results, {
            date  => sprintf("%4d-%02d-%02d", $year,$month,$day),
            time  => sprintf("%02d:%02d:%02d", $h,$m,$s),
            year  => $year,
            month => $month,
            day   => $day,
            hour  => $h,
            min   => $m,
            sec   => $s,
            lat   => $lat,
            lon   => $lon
        };
    }
    return $results;
}

#----------------------------------------
sub parse_all_csv {
    my $self = shift;
    my $csv_all = "date,time,lat,lon\n";
    my $results_ref = $self->parse_all_ref();
    for my $gps_ref (@$results_ref) {
        my $csv_data = sprintf("%4d-%02d-%02d,%02d:%02d:%02d,%.7f,%.7f\n",
            $gps_ref->{year},
            $gps_ref->{month},
            $gps_ref->{day},
            $gps_ref->{hour},
            $gps_ref->{min},
            $gps_ref->{sec},
            $gps_ref->{lat},
            $gps_ref->{lon});
        $csv_all .= $csv_data;
    }
    return $csv_all;
}

#----------------------------------------
sub parse_all_json {
    my $self = shift;
    return JSON::XS->new->pretty->encode( $self->parse_all_ref() );
}


1;
