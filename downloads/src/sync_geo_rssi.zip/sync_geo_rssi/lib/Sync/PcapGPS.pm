package Sync::PcapGPS;
use strict;
use warnings;
use lib qw/ lib /;
use JSON::XS;
use NMEA::Parser;
use TCPdump::Parser;
use Class::Accessor::Lite (
    rw  => [ qw/ gps pcap timezone / ]
    );

#----------------------------------------
sub new {
    my $self    = shift;
    my $arg_ref = shift || {};
    bless $arg_ref, $self;
}

#----------------------------------------
sub get_all_ref {
    my $self = shift;
    return unless -e $self->gps;
    return unless -e $self->pcap;

    my $sync_times_ref = {};
    my $sync_data_ref  = [];
    my $gps_parser     = NMEA::Parser->new({ file => $self->gps, timezone => $self->timezone });
    my $pcap_parser    = TCPdump::Parser->new({ file => $self->pcap });
    my $gps_data_ref   = $gps_parser->parse_all_ref();
    my $rssi_data_ref  = $pcap_parser->get_all_rssi_ref();
    
    my $index = 0;
    for my $r_ref (@$rssi_data_ref) {
        my $t = sprintf("%s%s", $r_ref->{date}, $r_ref->{time});
        $sync_times_ref->{$t} = $index;
        $index++;
    }

    for my $g_ref (@$gps_data_ref) {
        my $t = sprintf("%s%s", $g_ref->{date}, $g_ref->{time});
        if( defined $sync_times_ref->{$t} ) {
            my $i = $sync_times_ref->{$t};
            my $r_ref = $rssi_data_ref->[$i];
            my $data_ref = {
                date => $g_ref->{date},
                time => $g_ref->{time},
                lat  => $g_ref->{lat},
                lon  => $g_ref->{lon},
                rssi => $r_ref->{rssi}
            };
            push @$sync_data_ref, $data_ref;
        }
    }
    return $sync_data_ref;
}

#----------------------------------------
sub get_all_csv {
    my $self = shift;
    my $result_csv = "date,time,lat,lon,rssi\n";
    my $all_ref = $self->get_all_ref();
    for my $data_ref (@$all_ref) {
        $result_csv .= sprintf("%s,%s,%.7f,%.7f,%.1f\n", 
            $data_ref->{date}, 
            $data_ref->{time}, 
            $data_ref->{lat}, 
            $data_ref->{lon}, 
            $data_ref->{rssi});
    }
    return $result_csv;
}

#----------------------------------------
sub get_all_json {
    my $self = shift;
    my $all_ref = $self->get_all_ref();
    return JSON::XS->new->pretty(1)->encode( $all_ref );
}


1;
