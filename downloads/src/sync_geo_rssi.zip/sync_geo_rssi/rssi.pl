#!/usr/bin/env perl
use strict;
use warnings;
use lib qw/ lib /;
use TCPdump::Parser;

my $file   = "../../data/2012-09-18-RSSI-test/moni.pcap";
my $parser = TCPdump::Parser->new( {file => $file} );
print $parser->get_all_rssi_csv();

