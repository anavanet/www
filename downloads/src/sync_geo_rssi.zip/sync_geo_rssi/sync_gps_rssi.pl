#!/usr/bin/env perl
use strict;
use warnings;
use lib qw/ lib /;
use Sync::PcapGPS;

my $gps_file  = "../../data/2012-09-18-RSSI-test/gps.txt";
my $pcap_file = "../../data/2012-09-18-RSSI-test/moni.pcap";

my $sync = Sync::PcapGPS->new({ 
    gps      => $gps_file, 
    pcap     => $pcap_file, 
    timezone => '+2'
});
#print $sync->get_all_csv();
print $sync->get_all_json();

