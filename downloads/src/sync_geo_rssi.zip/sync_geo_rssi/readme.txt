* what's this
--------------------
This Perl library syncs NMEA and Pcap data. This library also
parse these data and find 'date', 'time', 'lat', 'lon' and 'RSSI'.
You can choose the output format (JSON/CSV).


* setup environment
--------------------
This library needs several CPAN libraries, shown as following.

- JSON::XS
- Class::Accessor::Lite

Install these libraries by CPAN or cpanm.


* sample files
--------------------
"./sync_gps_rssi.pl"
  This code generates sync data made from GPS&Pcap data.
  Configure 'NMEA', 'Pcap' files and 'Timezone'.

"./rssi.pl"
  This code parse pcap file and find 'date', 'time', 'RSSI'.
  Configure 'Pcap' file and 'Timezone'.

"./nmea.pl"
  This code parse NMEA file and find 'date', 'time', 'lat', 'lon'.
  Configure 'NMEA' file.


* cache files
--------------------
After parsing Pcap file, cache file is automatically generated.
You run the code again, you can get results 100 times faster.
If you want to delete cache files, see "./.cache".
  

* License
--------------------
Copyright (c) 2012, Satoshi MATSUURA (matsuura@is.naist.jp).
MIT License

